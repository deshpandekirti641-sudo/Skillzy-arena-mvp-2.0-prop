import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import {
  DollarSign,
  TrendingUp,
  Wallet,
  CreditCard,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  Filter,
  Download,
  Plus,
  Zap,
  Trophy,
  Target,
  Clock,
  AlertCircle,
  CheckCircle,
  XCircle,
} from "lucide-react"
import Link from "next/link"

export default function EarningsPage() {
  const transactions = [
    {
      id: "TXN001",
      type: "win",
      game: "Speed Chess",
      opponent: "ChessMaster99",
      amount: "+$45.00",
      fee: "$2.25",
      net: "+$42.75",
      date: "2025-01-26",
      time: "14:30",
      status: "completed",
    },
    {
      id: "TXN002",
      type: "loss",
      game: "Puzzle Rush",
      opponent: "PuzzleKing",
      amount: "-$15.00",
      fee: "$0.75",
      net: "-$15.75",
      date: "2025-01-26",
      time: "12:15",
      status: "completed",
    },
    {
      id: "TXN003",
      type: "withdrawal",
      game: "Bank Transfer",
      opponent: "Wells Fargo ****1234",
      amount: "-$200.00",
      fee: "$5.00",
      net: "-$205.00",
      date: "2025-01-25",
      time: "16:45",
      status: "pending",
    },
    {
      id: "TXN004",
      type: "deposit",
      game: "Credit Card",
      opponent: "Visa ****5678",
      amount: "+$100.00",
      fee: "$3.00",
      net: "+$97.00",
      date: "2025-01-25",
      time: "10:20",
      status: "completed",
    },
    {
      id: "TXN005",
      type: "win",
      game: "Word Blitz",
      opponent: "WordWizard",
      amount: "+$25.00",
      fee: "$1.25",
      net: "+$23.75",
      date: "2025-01-24",
      time: "19:30",
      status: "completed",
    },
  ]

  const monthlyEarnings = [
    { month: "Jan", earnings: 1247, games: 45 },
    { month: "Dec", earnings: 2156, games: 67 },
    { month: "Nov", earnings: 1834, games: 52 },
    { month: "Oct", earnings: 1456, games: 41 },
    { month: "Sep", earnings: 1789, games: 48 },
    { month: "Aug", earnings: 2234, games: 71 },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-gradient">SKILLZY</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
            <Link href="/games" className="text-muted-foreground hover:text-foreground transition-colors">
              Games
            </Link>
            <Link href="/tournaments" className="text-muted-foreground hover:text-foreground transition-colors">
              Tournaments
            </Link>
            <Link href="/earnings" className="text-foreground font-medium">
              Earnings
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Balance</div>
              <div className="font-bold text-primary">$1,247.50</div>
            </div>
            <Button variant="outline" size="sm">
              Profile
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Earnings & Wallet</h1>
          <p className="text-muted-foreground">Manage your gaming earnings and financial transactions</p>
        </div>

        {/* Wallet Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-border/50 bg-primary/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Available Balance</p>
                  <p className="text-3xl font-bold text-primary">$1,247.50</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +$127.50 this week
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Earnings</p>
                  <p className="text-2xl font-bold text-accent">$3,247.50</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <Trophy className="w-3 h-3 mr-1" />
                    All time
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Withdrawals</p>
                  <p className="text-2xl font-bold text-chart-3">$200.00</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <Clock className="w-3 h-3 mr-1" />
                    Processing
                  </p>
                </div>
                <div className="w-12 h-12 bg-chart-3/20 rounded-full flex items-center justify-center">
                  <ArrowUpRight className="w-6 h-6 text-chart-3" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">This Month</p>
                  <p className="text-2xl font-bold text-chart-4">$1,247.50</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <Target className="w-3 h-3 mr-1" />
                    45 games played
                  </p>
                </div>
                <div className="w-12 h-12 bg-chart-4/20 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-chart-4" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-4 mb-8">
          <Button className="glow-effect">
            <Plus className="w-4 h-4 mr-2" />
            Add Funds
          </Button>
          <Button variant="outline">
            <ArrowUpRight className="w-4 h-4 mr-2" />
            Withdraw
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Statement
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="transactions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-[500px]">
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
            <TabsTrigger value="deposit">Deposit</TabsTrigger>
          </TabsList>

          {/* Transactions Tab */}
          <TabsContent value="transactions" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Transaction History</CardTitle>
                    <CardDescription>Your recent gaming and financial transactions</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[120px]">
                        <SelectValue placeholder="Filter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="wins">Wins</SelectItem>
                        <SelectItem value="losses">Losses</SelectItem>
                        <SelectItem value="deposits">Deposits</SelectItem>
                        <SelectItem value="withdrawals">Withdrawals</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm">
                      <Filter className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-border/50 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            transaction.type === "win"
                              ? "bg-primary/20"
                              : transaction.type === "loss"
                                ? "bg-destructive/20"
                                : transaction.type === "deposit"
                                  ? "bg-accent/20"
                                  : "bg-chart-3/20"
                          }`}
                        >
                          {transaction.type === "win" && <Trophy className="w-5 h-5 text-primary" />}
                          {transaction.type === "loss" && <Target className="w-5 h-5 text-destructive" />}
                          {transaction.type === "deposit" && <ArrowDownLeft className="w-5 h-5 text-accent" />}
                          {transaction.type === "withdrawal" && <ArrowUpRight className="w-5 h-5 text-chart-3" />}
                        </div>
                        <div>
                          <div className="font-semibold">{transaction.game}</div>
                          <div className="text-sm text-muted-foreground">
                            {transaction.type === "win" || transaction.type === "loss"
                              ? `vs ${transaction.opponent}`
                              : transaction.opponent}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {transaction.date} at {transaction.time}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`font-bold text-lg ${
                            transaction.amount.startsWith("+") ? "text-primary" : "text-destructive"
                          }`}
                        >
                          {transaction.amount}
                        </div>
                        <div className="text-sm text-muted-foreground">Fee: {transaction.fee}</div>
                        <div className="flex items-center text-xs">
                          {transaction.status === "completed" && (
                            <>
                              <CheckCircle className="w-3 h-3 mr-1 text-primary" />
                              <span className="text-primary">Completed</span>
                            </>
                          )}
                          {transaction.status === "pending" && (
                            <>
                              <Clock className="w-3 h-3 mr-1 text-chart-3" />
                              <span className="text-chart-3">Pending</span>
                            </>
                          )}
                          {transaction.status === "failed" && (
                            <>
                              <XCircle className="w-3 h-3 mr-1 text-destructive" />
                              <span className="text-destructive">Failed</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Monthly Earnings</CardTitle>
                  <CardDescription>Your earnings over the last 6 months</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {monthlyEarnings.map((month, index) => (
                      <div key={month.month} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-xs font-bold text-primary">
                            {month.month}
                          </div>
                          <div>
                            <div className="font-medium">{month.month} 2025</div>
                            <div className="text-sm text-muted-foreground">{month.games} games</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-primary">${month.earnings}</div>
                          <div className="text-sm text-muted-foreground">
                            ${(month.earnings / month.games).toFixed(2)}/game
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                  <CardDescription>Your gaming performance statistics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Win Rate</span>
                      <span className="text-sm text-muted-foreground">73%</span>
                    </div>
                    <Progress value={73} className="h-2" />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Average Earnings per Game</span>
                      <span className="text-sm text-muted-foreground">$27.72</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Monthly Goal Progress</span>
                      <span className="text-sm text-muted-foreground">$1,247 / $2,000</span>
                    </div>
                    <Progress value={62} className="h-2" />
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-primary">127</div>
                      <div className="text-sm text-muted-foreground">Games Won</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-accent">47</div>
                      <div className="text-sm text-muted-foreground">Games Lost</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Withdraw Tab */}
          <TabsContent value="withdraw" className="space-y-6">
            <Card className="border-border/50 max-w-2xl">
              <CardHeader>
                <CardTitle>Withdraw Funds</CardTitle>
                <CardDescription>Transfer your earnings to your bank account or payment method</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Available Balance</span>
                    <span className="text-2xl font-bold text-primary">$1,247.50</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="withdrawAmount">Withdrawal Amount</Label>
                    <Input id="withdrawAmount" type="number" placeholder="0.00" className="text-lg" />
                    <p className="text-sm text-muted-foreground mt-1">
                      Minimum withdrawal: $10.00 • Maximum: $1,247.50
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="withdrawMethod">Withdrawal Method</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select withdrawal method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bank">Bank Transfer (2-3 business days)</SelectItem>
                        <SelectItem value="paypal">PayPal (Instant)</SelectItem>
                        <SelectItem value="crypto">Cryptocurrency (Instant)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Withdrawal Amount</span>
                      <span>$0.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Processing Fee (2.5%)</span>
                      <span>$0.00</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>You'll Receive</span>
                      <span>$0.00</span>
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5" />
                    <div className="text-sm text-muted-foreground">
                      <p>Withdrawals are processed within 1-3 business days depending on your chosen method.</p>
                      <p className="mt-1">A processing fee of 2.5% applies to all withdrawals.</p>
                    </div>
                  </div>

                  <Button className="w-full glow-effect" disabled>
                    <ArrowUpRight className="w-4 h-4 mr-2" />
                    Withdraw Funds
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Deposit Tab */}
          <TabsContent value="deposit" className="space-y-6">
            <Card className="border-border/50 max-w-2xl">
              <CardHeader>
                <CardTitle>Add Funds</CardTitle>
                <CardDescription>Add money to your account to participate in higher stakes games</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-3 gap-4">
                  {[50, 100, 250].map((amount) => (
                    <Button key={amount} variant="outline" className="h-16 text-lg bg-transparent">
                      ${amount}
                    </Button>
                  ))}
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="depositAmount">Custom Amount</Label>
                    <Input id="depositAmount" type="number" placeholder="0.00" className="text-lg" />
                    <p className="text-sm text-muted-foreground mt-1">Minimum deposit: $10.00 • Maximum: $5,000.00</p>
                  </div>

                  <div>
                    <Label htmlFor="paymentMethod">Payment Method</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="card">Credit/Debit Card</SelectItem>
                        <SelectItem value="bank">Bank Transfer</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="crypto">Cryptocurrency</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Deposit Amount</span>
                      <span>$0.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Processing Fee (3%)</span>
                      <span>$0.00</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>Total Charge</span>
                      <span>$0.00</span>
                    </div>
                  </div>

                  <Button className="w-full glow-effect" disabled>
                    <CreditCard className="w-4 h-4 mr-2" />
                    Add Funds
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
