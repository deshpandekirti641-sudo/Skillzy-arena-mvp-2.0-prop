"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Pause, Trophy, Users, Clock, Coins, Volume2, VolumeX, Zap, Target, Crown } from "lucide-react"
import Link from "next/link"

export default function GamesPage() {
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [matchTime, setMatchTime] = useState(60)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [betAmount] = useState(10)
  const [prizePool] = useState(20)
  const [winnerPayout] = useState(16)
  const [serverFee] = useState(4)

  const games = [
    {
      id: "carrom",
      name: "Carrom Master",
      description: "Strategic board game with precise shots",
      image: "/carrom-board-neon.jpg",
      difficulty: "Medium",
      players: "1.2K",
      icon: Target,
    },
    {
      id: "chess",
      name: "Speed Chess",
      description: "Fast-paced chess with time pressure",
      image: "/chess-board-neon-gaming.jpg",
      difficulty: "Expert",
      players: "2.1K",
      icon: Crown,
    },
    {
      id: "snakeladder",
      name: "Snake & Ladder Rush",
      description: "Classic board game with modern twists",
      image: "/snake-ladder-neon.jpg",
      difficulty: "Easy",
      players: "3.5K",
      icon: Zap,
    },
  ]

  // Match timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying && matchTime > 0) {
      interval = setInterval(() => {
        setMatchTime((prev) => {
          if (prev <= 1) {
            setIsPlaying(false)
            // Trigger match end logic
            handleMatchEnd()
            return 60
          }
          return prev - 1
        })
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, matchTime])

  const handleMatchEnd = () => {
    // Play match end sound
    if (soundEnabled) {
      const audio = new Audio("/sounds/match-end.mp3")
      audio.play().catch(() => {})
    }

    // Simulate match result and wallet update
    console.log("[v0] Match ended - processing payouts")
    // Winner gets 16 rupees, server gets 4 rupees
  }

  const startMatch = (gameId: string) => {
    setSelectedGame(gameId)
    setIsPlaying(true)
    setMatchTime(60)

    // Play start sound
    if (soundEnabled) {
      const audio = new Audio("/sounds/match-start.mp3")
      audio.play().catch(() => {})
    }
  }

  const pauseMatch = () => {
    setIsPlaying(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-gradient">SKILLZY</span>
            </Link>
            <Badge variant="secondary" className="pulse-neon">
              <Trophy className="w-3 h-3 mr-1" />
              Gaming Arena
            </Badge>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => setSoundEnabled(!soundEnabled)}>
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </Button>
            <div className="text-sm">
              <div className="text-muted-foreground">Wallet Balance</div>
              <div className="font-bold text-primary">₹1,250</div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Match Status */}
        {isPlaying && selectedGame && (
          <Card className="mb-8 border-primary/50 bg-primary/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Match in Progress</h3>
                    <p className="text-muted-foreground">{games.find((g) => g.id === selectedGame)?.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary">{matchTime}s</div>
                  <div className="text-sm text-muted-foreground">Time Remaining</div>
                </div>
              </div>

              <Progress value={((60 - matchTime) / 60) * 100} className="mb-4" />

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Bet Amount</div>
                    <div className="font-bold text-accent">₹{betAmount}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Prize Pool</div>
                    <div className="font-bold text-primary">₹{prizePool}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Winner Gets</div>
                    <div className="font-bold text-chart-2">₹{winnerPayout}</div>
                  </div>
                </div>

                <Button onClick={pauseMatch} variant="outline">
                  <Pause className="w-4 h-4 mr-2" />
                  Pause
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {games.map((game) => (
            <Card key={game.id} className="group hover:border-primary/50 transition-all duration-300 overflow-hidden">
              <div className="aspect-video bg-muted relative overflow-hidden">
                <img
                  src={game.image || `/placeholder.svg?height=200&width=300&query=${game.name} game board`}
                  alt={game.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3">
                  <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
                    <game.icon className="w-3 h-3 mr-1" />
                    {game.difficulty}
                  </Badge>
                </div>
                <div className="absolute top-3 right-3">
                  <Badge variant="secondary" className="bg-accent/20 text-accent border-accent/30">
                    ₹{winnerPayout} Win
                  </Badge>
                </div>

                {/* Game overlay effects */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button className="w-full glow-effect" onClick={() => startMatch(game.id)} disabled={isPlaying}>
                    <Play className="w-4 h-4 mr-2" />
                    Start Match
                  </Button>
                </div>
              </div>

              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-semibold">{game.name}</h3>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Users className="w-4 h-4 mr-1" />
                    {game.players}
                  </div>
                </div>
                <p className="text-muted-foreground mb-4">{game.description}</p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center text-muted-foreground">
                      <Coins className="w-4 h-4 mr-1" />₹{betAmount} bet
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <Clock className="w-4 h-4 mr-1" />
                      60s match
                    </div>
                  </div>

                  {!isPlaying && (
                    <Button size="sm" onClick={() => startMatch(game.id)} className="group-hover:glow-effect">
                      Play Now
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Game Rules & Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Trophy className="w-5 h-5 mr-2 text-primary" />
              Game Rules & Payouts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="rules" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="rules">Rules</TabsTrigger>
                <TabsTrigger value="payouts">Payouts</TabsTrigger>
                <TabsTrigger value="features">Features</TabsTrigger>
              </TabsList>

              <TabsContent value="rules" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border border-border rounded-lg">
                    <h4 className="font-semibold mb-2 text-primary">Carrom Master</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Pocket your pieces before opponent</li>
                      <li>• Queen must be covered to win</li>
                      <li>• Precise aim and strategy required</li>
                      <li>• 60-second time limit</li>
                    </ul>
                  </div>
                  <div className="p-4 border border-border rounded-lg">
                    <h4 className="font-semibold mb-2 text-primary">Speed Chess</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Checkmate or most pieces wins</li>
                      <li>• Fast-paced 60-second matches</li>
                      <li>• Strategic thinking under pressure</li>
                      <li>• Standard chess rules apply</li>
                    </ul>
                  </div>
                  <div className="p-4 border border-border rounded-lg">
                    <h4 className="font-semibold mb-2 text-primary">Snake & Ladder Rush</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Race to reach 100 first</li>
                      <li>• Snakes slide you down</li>
                      <li>• Ladders boost you up</li>
                      <li>• Luck meets strategy</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="payouts" className="space-y-4">
                <div className="bg-muted/30 p-6 rounded-lg">
                  <h4 className="font-semibold mb-4 text-center">Match Payout Structure</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div className="p-3 bg-background rounded-lg">
                      <div className="text-sm text-muted-foreground">Entry Fee</div>
                      <div className="text-lg font-bold text-accent">₹{betAmount}</div>
                    </div>
                    <div className="p-3 bg-background rounded-lg">
                      <div className="text-sm text-muted-foreground">Prize Pool</div>
                      <div className="text-lg font-bold text-primary">₹{prizePool}</div>
                    </div>
                    <div className="p-3 bg-background rounded-lg">
                      <div className="text-sm text-muted-foreground">Winner Gets</div>
                      <div className="text-lg font-bold text-chart-2">₹{winnerPayout}</div>
                    </div>
                    <div className="p-3 bg-background rounded-lg">
                      <div className="text-sm text-muted-foreground">Server Fee</div>
                      <div className="text-lg font-bold text-muted-foreground">₹{serverFee}</div>
                    </div>
                  </div>
                  <div className="mt-4 text-center text-sm text-muted-foreground">
                    Payouts are automatically credited to winner's wallet when match ends
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="features" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 text-primary">Game Features</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-center">
                        <Zap className="w-4 h-4 mr-2 text-accent" />
                        Real-time multiplayer gameplay
                      </li>
                      <li className="flex items-center">
                        <Volume2 className="w-4 h-4 mr-2 text-accent" />
                        Immersive sound effects (SFX)
                      </li>
                      <li className="flex items-center">
                        <Trophy className="w-4 h-4 mr-2 text-accent" />
                        Visual effects and animations (VFX)
                      </li>
                      <li className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-accent" />
                        60-second match duration
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 text-primary">Platform Features</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-center">
                        <Coins className="w-4 h-4 mr-2 text-accent" />
                        Instant wallet transactions
                      </li>
                      <li className="flex items-center">
                        <Users className="w-4 h-4 mr-2 text-accent" />
                        1v1 competitive matches
                      </li>
                      <li className="flex items-center">
                        <Target className="w-4 h-4 mr-2 text-accent" />
                        Skill-based matchmaking
                      </li>
                      <li className="flex items-center">
                        <Crown className="w-4 h-4 mr-2 text-accent" />
                        Leaderboard rankings
                      </li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
