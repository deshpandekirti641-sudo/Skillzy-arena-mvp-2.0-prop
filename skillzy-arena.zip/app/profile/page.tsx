import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { User, Trophy, Target, Camera, Shield, Bell, Eye, Lock, Award, Zap, Edit3 } from "lucide-react"
import Link from "next/link"

export default function ProfilePage() {
  const achievements = [
    { title: "First Victory", description: "Win your first game", unlocked: true, date: "Jan 15, 2025" },
    { title: "Winning Streak", description: "Win 10 games in a row", unlocked: true, date: "Jan 20, 2025" },
    { title: "Speed Demon", description: "Complete 50 speed chess games", unlocked: true, date: "Jan 22, 2025" },
    { title: "Puzzle Master", description: "Solve 1000 puzzles", unlocked: false, progress: 76 },
    { title: "Tournament Champion", description: "Win a major tournament", unlocked: false, progress: 0 },
    { title: "Elite Player", description: "Reach top 10 on leaderboard", unlocked: false, progress: 20 },
  ]

  const gameStats = [
    { game: "Speed Chess", played: 89, won: 67, winRate: 75, earnings: "$1,245", rating: 1847 },
    { game: "Puzzle Rush", played: 156, won: 134, winRate: 86, earnings: "$890", rating: 2156 },
    { game: "Word Blitz", played: 203, won: 145, winRate: 71, earnings: "$1,112", rating: 1923 },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-gradient">SKILLZY</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
            <Link href="/games" className="text-muted-foreground hover:text-foreground transition-colors">
              Games
            </Link>
            <Link href="/tournaments" className="text-muted-foreground hover:text-foreground transition-colors">
              Tournaments
            </Link>
            <Link href="/profile" className="text-foreground font-medium">
              Profile
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Balance</div>
              <div className="font-bold text-primary">$1,247.50</div>
            </div>
            <Button variant="outline" size="sm">
              Settings
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="mb-8">
          <Card className="border-border/50 bg-gradient-to-r from-primary/5 via-background to-accent/5">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8">
                <div className="relative">
                  <Avatar className="w-32 h-32 border-4 border-primary/20">
                    <AvatarImage src="/placeholder.svg?height=128&width=128" />
                    <AvatarFallback className="text-2xl">PG</AvatarFallback>
                  </Avatar>
                  <Button size="sm" className="absolute -bottom-2 -right-2 rounded-full w-10 h-10 p-0">
                    <Camera className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex-1">
                  <div className="flex items-center space-x-4 mb-4">
                    <h1 className="text-3xl font-bold">ProGamer_X</h1>
                    <Badge className="pulse-neon">Legend Tier</Badge>
                    <Badge variant="outline">🇺🇸 USA</Badge>
                  </div>

                  <p className="text-muted-foreground mb-4 max-w-2xl">
                    Competitive gamer specializing in chess and puzzle games. Been dominating the arena since 2024.
                    Always looking for challenging opponents!
                  </p>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">$3,247</div>
                      <div className="text-sm text-muted-foreground">Total Earnings</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-accent">347</div>
                      <div className="text-sm text-muted-foreground">Games Played</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-chart-3">75%</div>
                      <div className="text-sm text-muted-foreground">Win Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-chart-4">#47</div>
                      <div className="text-sm text-muted-foreground">Global Rank</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-[600px]">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" defaultValue="John" />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" defaultValue="Doe" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input id="username" defaultValue="ProGamer_X" />
                  </div>

                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      defaultValue="Competitive gamer specializing in chess and puzzle games. Been dominating the arena since 2024."
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="country">Country</Label>
                      <Select defaultValue="us">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="us">🇺🇸 United States</SelectItem>
                          <SelectItem value="ca">🇨🇦 Canada</SelectItem>
                          <SelectItem value="gb">🇬🇧 United Kingdom</SelectItem>
                          <SelectItem value="de">🇩🇪 Germany</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="timezone">Timezone</Label>
                      <Select defaultValue="est">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="est">EST (UTC-5)</SelectItem>
                          <SelectItem value="pst">PST (UTC-8)</SelectItem>
                          <SelectItem value="gmt">GMT (UTC+0)</SelectItem>
                          <SelectItem value="cet">CET (UTC+1)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button className="w-full">
                    <Edit3 className="w-4 h-4 mr-2" />
                    Update Profile
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Trophy className="w-5 h-5 mr-2" />
                    Recent Achievements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {achievements
                      .filter((a) => a.unlocked)
                      .slice(0, 4)
                      .map((achievement, index) => (
                        <div
                          key={index}
                          className="flex items-center space-x-3 p-3 rounded-lg bg-primary/5 border border-primary/20"
                        >
                          <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                            <Trophy className="w-5 h-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <div className="font-semibold">{achievement.title}</div>
                            <div className="text-sm text-muted-foreground">{achievement.description}</div>
                          </div>
                          <div className="text-xs text-muted-foreground">{achievement.date}</div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Statistics Tab */}
          <TabsContent value="stats" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2" />
                  Game Statistics
                </CardTitle>
                <CardDescription>Your performance across different games</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {gameStats.map((stat, index) => (
                    <div key={index} className="p-4 rounded-lg border border-border/50">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">{stat.game}</h3>
                        <Badge variant="outline">Rating: {stat.rating}</Badge>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                        <div className="text-center">
                          <div className="text-xl font-bold text-primary">{stat.played}</div>
                          <div className="text-sm text-muted-foreground">Played</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-accent">{stat.won}</div>
                          <div className="text-sm text-muted-foreground">Won</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-chart-3">{stat.winRate}%</div>
                          <div className="text-sm text-muted-foreground">Win Rate</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-chart-4">{stat.earnings}</div>
                          <div className="text-sm text-muted-foreground">Earnings</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-chart-5">{stat.played - stat.won}</div>
                          <div className="text-sm text-muted-foreground">Lost</div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Win Rate</span>
                          <span>{stat.winRate}%</span>
                        </div>
                        <Progress value={stat.winRate} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2" />
                  Achievements
                </CardTitle>
                <CardDescription>
                  Track your progress and unlock rewards • {achievements.filter((a) => a.unlocked).length}/
                  {achievements.length} unlocked
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {achievements.map((achievement, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border transition-all ${
                        achievement.unlocked ? "bg-primary/5 border-primary/20" : "border-border/50 hover:border-border"
                      }`}
                    >
                      <div className="flex items-start space-x-4">
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center ${
                            achievement.unlocked ? "bg-primary/20" : "bg-muted"
                          }`}
                        >
                          <Trophy
                            className={`w-6 h-6 ${achievement.unlocked ? "text-primary" : "text-muted-foreground"}`}
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold">{achievement.title}</h3>
                            {achievement.unlocked && (
                              <Badge className="bg-primary/20 text-primary border-primary/30">Unlocked</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>

                          {achievement.unlocked ? (
                            <div className="text-xs text-muted-foreground">Unlocked on {achievement.date}</div>
                          ) : (
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Progress</span>
                                <span>{achievement.progress}%</span>
                              </div>
                              <Progress value={achievement.progress} className="h-2" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bell className="w-5 h-5 mr-2" />
                    Notifications
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Game Invitations</div>
                      <div className="text-sm text-muted-foreground">Receive notifications when players invite you</div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Tournament Updates</div>
                      <div className="text-sm text-muted-foreground">Get notified about tournament results</div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Earnings Alerts</div>
                      <div className="text-sm text-muted-foreground">Notifications for wins and withdrawals</div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Marketing Emails</div>
                      <div className="text-sm text-muted-foreground">Promotional offers and updates</div>
                    </div>
                    <Switch />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="w-5 h-5 mr-2" />
                    Privacy Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Profile Visibility</div>
                      <div className="text-sm text-muted-foreground">Who can see your profile</div>
                    </div>
                    <Select defaultValue="public">
                      <SelectTrigger className="w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="friends">Friends Only</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Show Earnings</div>
                      <div className="text-sm text-muted-foreground">Display earnings on leaderboards</div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Online Status</div>
                      <div className="text-sm text-muted-foreground">Show when you're online</div>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Game History</div>
                      <div className="text-sm text-muted-foreground">Allow others to view your game history</div>
                    </div>
                    <Switch />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lock className="w-5 h-5 mr-2" />
                    Account Security
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input id="currentPassword" type="password" />
                  </div>

                  <div>
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input id="newPassword" type="password" />
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <Input id="confirmPassword" type="password" />
                  </div>

                  <Button className="w-full">Update Password</Button>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="w-5 h-5 mr-2" />
                    Two-Factor Authentication
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">2FA Status</div>
                      <div className="text-sm text-muted-foreground">Extra security for your account</div>
                    </div>
                    <Badge variant="outline" className="text-destructive border-destructive">
                      Disabled
                    </Badge>
                  </div>

                  <p className="text-sm text-muted-foreground">
                    Two-factor authentication adds an extra layer of security to your account by requiring a code from
                    your phone in addition to your password.
                  </p>

                  <Button variant="outline" className="w-full bg-transparent">
                    Enable 2FA
                  </Button>

                  <Separator />

                  <div>
                    <h4 className="font-medium mb-2">Active Sessions</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-2 rounded border border-border/50">
                        <div>
                          <div className="text-sm font-medium">Current Session</div>
                          <div className="text-xs text-muted-foreground">Chrome on Windows • New York, NY</div>
                        </div>
                        <Badge variant="secondary">Active</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
