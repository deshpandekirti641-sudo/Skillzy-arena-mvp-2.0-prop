import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Trophy,
  DollarSign,
  Users,
  Zap,
  Play,
  Clock,
  Target,
  TrendingUp,
  Star,
  Crown,
  Gamepad2,
  Calendar,
  Award,
} from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-gradient">SKILLZY</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/dashboard" className="text-foreground font-medium">
              Dashboard
            </Link>
            <Link href="/games" className="text-muted-foreground hover:text-foreground transition-colors">
              Games
            </Link>
            <Link href="/tournaments" className="text-muted-foreground hover:text-foreground transition-colors">
              Tournaments
            </Link>
            <Link href="/leaderboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Leaderboard
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Balance</div>
              <div className="font-bold text-primary">$1,247.50</div>
            </div>
            <Button variant="outline" size="sm">
              Profile
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, ProGamer!</h1>
          <p className="text-muted-foreground">Ready to dominate the arena today?</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Earnings</p>
                  <p className="text-2xl font-bold text-primary">$3,247.50</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +12.5% this week
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Games Won</p>
                  <p className="text-2xl font-bold text-accent">127</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <Trophy className="w-3 h-3 mr-1" />
                    73% win rate
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Current Rank</p>
                  <p className="text-2xl font-bold text-chart-3">#47</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <Star className="w-3 h-3 mr-1" />
                    Elite tier
                  </p>
                </div>
                <div className="w-12 h-12 bg-chart-3/20 rounded-full flex items-center justify-center">
                  <Crown className="w-6 h-6 text-chart-3" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Streak</p>
                  <p className="text-2xl font-bold text-chart-4">8 days</p>
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    <Zap className="w-3 h-3 mr-1" />
                    Keep it up!
                  </p>
                </div>
                <div className="w-12 h-12 bg-chart-4/20 rounded-full flex items-center justify-center">
                  <Zap className="w-6 h-6 text-chart-4" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="games" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-[400px]">
            <TabsTrigger value="games">Games</TabsTrigger>
            <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          {/* Games Tab */}
          <TabsContent value="games" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Available Games</h2>
              <Button variant="outline">View All Games</Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "Speed Chess",
                  description: "Fast-paced chess matches",
                  entryFee: "$10",
                  prize: "$500",
                  players: "2.1K",
                  difficulty: "Expert",
                  image: "/chess-board-neon-gaming.jpg",
                  status: "Live",
                  timeLeft: "2h 15m",
                },
                {
                  title: "Puzzle Rush",
                  description: "Solve puzzles under pressure",
                  entryFee: "$5",
                  prize: "$250",
                  players: "1.8K",
                  difficulty: "Medium",
                  image: "/puzzle-game-neon-digital.jpg",
                  status: "Starting Soon",
                  timeLeft: "45m",
                },
                {
                  title: "Word Blitz",
                  description: "Vocabulary challenge",
                  entryFee: "$3",
                  prize: "$150",
                  players: "3.2K",
                  difficulty: "Easy",
                  image: "/word-game-letters-neon.jpg",
                  status: "Live",
                  timeLeft: "1h 30m",
                },
              ].map((game, index) => (
                <Card key={index} className="group hover:border-primary/50 transition-all duration-300 overflow-hidden">
                  <div className="aspect-video bg-muted relative overflow-hidden">
                    <img
                      src={game.image || "/placeholder.svg"}
                      alt={game.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge variant={game.status === "Live" ? "default" : "secondary"} className="pulse-neon">
                        {game.status}
                      </Badge>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
                        {game.prize} Prize
                      </Badge>
                    </div>
                    <div className="absolute bottom-3 left-3">
                      <div className="flex items-center text-white text-sm bg-black/50 rounded px-2 py-1">
                        <Clock className="w-3 h-3 mr-1" />
                        {game.timeLeft}
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold">{game.title}</h3>
                      <Badge
                        variant={
                          game.difficulty === "Expert"
                            ? "destructive"
                            : game.difficulty === "Medium"
                              ? "default"
                              : "secondary"
                        }
                      >
                        {game.difficulty}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-4">{game.description}</p>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Users className="w-4 h-4 mr-1" />
                        {game.players} playing
                      </div>
                      <div className="text-sm font-medium">Entry: {game.entryFee}</div>
                    </div>
                    <Button className="w-full group-hover:glow-effect">
                      <Play className="w-4 h-4 mr-2" />
                      Join Game
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Tournaments Tab */}
          <TabsContent value="tournaments" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Active Tournaments</h2>
              <Button variant="outline">Create Tournament</Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[
                {
                  title: "Weekly Chess Championship",
                  description: "Compete against the best chess players",
                  prize: "$5,000",
                  participants: "256/512",
                  startTime: "Tomorrow 8:00 PM",
                  entryFee: "$25",
                  status: "Registration Open",
                },
                {
                  title: "Puzzle Masters Tournament",
                  description: "Ultimate puzzle solving competition",
                  prize: "$2,500",
                  participants: "128/256",
                  startTime: "Friday 6:00 PM",
                  entryFee: "$15",
                  status: "Registration Open",
                },
              ].map((tournament, index) => (
                <Card key={index} className="border-border/50">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl">{tournament.title}</CardTitle>
                      <Badge className="pulse-neon">{tournament.status}</Badge>
                    </div>
                    <CardDescription>{tournament.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Prize Pool</p>
                        <p className="text-lg font-bold text-primary">{tournament.prize}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Entry Fee</p>
                        <p className="text-lg font-bold">{tournament.entryFee}</p>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-sm text-muted-foreground">Participants</p>
                        <p className="text-sm font-medium">{tournament.participants}</p>
                      </div>
                      <Progress
                        value={
                          (Number.parseInt(tournament.participants.split("/")[0]) /
                            Number.parseInt(tournament.participants.split("/")[1])) *
                          100
                        }
                        className="h-2"
                      />
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4 mr-2" />
                      Starts {tournament.startTime}
                    </div>
                    <Button className="w-full glow-effect">Register Now</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Achievements</h2>
              <div className="text-sm text-muted-foreground">Progress: 24/50 achievements unlocked</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "First Victory",
                  description: "Win your first game",
                  icon: Trophy,
                  unlocked: true,
                  progress: 100,
                  reward: "$5",
                },
                {
                  title: "Winning Streak",
                  description: "Win 10 games in a row",
                  icon: Zap,
                  unlocked: true,
                  progress: 100,
                  reward: "$25",
                },
                {
                  title: "Speed Demon",
                  description: "Complete 50 speed chess games",
                  icon: Clock,
                  unlocked: false,
                  progress: 76,
                  reward: "$50",
                },
                {
                  title: "Puzzle Master",
                  description: "Solve 1000 puzzles",
                  icon: Target,
                  unlocked: false,
                  progress: 45,
                  reward: "$100",
                },
                {
                  title: "Tournament Champion",
                  description: "Win a major tournament",
                  icon: Crown,
                  unlocked: false,
                  progress: 0,
                  reward: "$500",
                },
                {
                  title: "Elite Player",
                  description: "Reach top 10 on leaderboard",
                  icon: Star,
                  unlocked: false,
                  progress: 20,
                  reward: "$1000",
                },
              ].map((achievement, index) => (
                <Card
                  key={index}
                  className={`border-border/50 ${achievement.unlocked ? "bg-primary/5 border-primary/20" : ""}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          achievement.unlocked ? "bg-primary/20" : "bg-muted"
                        }`}
                      >
                        <achievement.icon
                          className={`w-6 h-6 ${achievement.unlocked ? "text-primary" : "text-muted-foreground"}`}
                        />
                      </div>
                      {achievement.unlocked && (
                        <Badge className="bg-primary/20 text-primary border-primary/30">Unlocked</Badge>
                      )}
                    </div>
                    <h3 className="font-semibold mb-2">{achievement.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{achievement.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Progress</span>
                        <span>{achievement.progress}%</span>
                      </div>
                      <Progress value={achievement.progress} className="h-2" />
                      <div className="text-sm text-muted-foreground">
                        Reward: <span className="text-primary font-medium">{achievement.reward}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Recent Activity</h2>
              <Button variant="outline">View All</Button>
            </div>

            <Card className="border-border/50">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {[
                    {
                      type: "win",
                      game: "Speed Chess",
                      opponent: "ChessMaster99",
                      earnings: "+$45.00",
                      time: "2 hours ago",
                      icon: Trophy,
                    },
                    {
                      type: "loss",
                      game: "Puzzle Rush",
                      opponent: "PuzzleKing",
                      earnings: "-$15.00",
                      time: "4 hours ago",
                      icon: Target,
                    },
                    {
                      type: "win",
                      game: "Word Blitz",
                      opponent: "WordWizard",
                      earnings: "+$25.00",
                      time: "6 hours ago",
                      icon: Gamepad2,
                    },
                    {
                      type: "achievement",
                      game: "Achievement Unlocked",
                      opponent: "Winning Streak",
                      earnings: "+$25.00",
                      time: "1 day ago",
                      icon: Award,
                    },
                  ].map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            activity.type === "win"
                              ? "bg-primary/20"
                              : activity.type === "achievement"
                                ? "bg-accent/20"
                                : "bg-muted"
                          }`}
                        >
                          <activity.icon
                            className={`w-5 h-5 ${
                              activity.type === "win"
                                ? "text-primary"
                                : activity.type === "achievement"
                                  ? "text-accent"
                                  : "text-muted-foreground"
                            }`}
                          />
                        </div>
                        <div>
                          <div className="font-medium">{activity.game}</div>
                          <div className="text-sm text-muted-foreground">
                            {activity.type === "achievement" ? activity.opponent : `vs ${activity.opponent}`}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div
                          className={`font-bold ${
                            activity.earnings.startsWith("+") ? "text-primary" : "text-destructive"
                          }`}
                        >
                          {activity.earnings}
                        </div>
                        <div className="text-sm text-muted-foreground">{activity.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
