import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trophy, Zap, Crown, Star, Medal, Target, Clock, Gamepad2, ChevronUp, ChevronDown, Minus } from "lucide-react"
import Link from "next/link"

export default function LeaderboardPage() {
  const topEarners = [
    {
      rank: 1,
      name: "ProGamer_X",
      avatar: "/placeholder.svg?height=40&width=40",
      earnings: "$12,450",
      games: 347,
      winRate: 89,
      change: "up",
      tier: "Legend",
      country: "🇺🇸",
    },
    {
      rank: 2,
      name: "SkillMaster",
      avatar: "/placeholder.svg?height=40&width=40",
      earnings: "$9,890",
      games: 298,
      winRate: 85,
      change: "down",
      tier: "Elite",
      country: "🇬🇧",
    },
    {
      rank: 3,
      name: "QuickWin",
      avatar: "/placeholder.svg?height=40&width=40",
      earnings: "$8,340",
      games: 285,
      winRate: 82,
      change: "up",
      tier: "Elite",
      country: "🇨🇦",
    },
    {
      rank: 4,
      name: "GameChamp",
      avatar: "/placeholder.svg?height=40&width=40",
      earnings: "$7,980",
      games: 272,
      winRate: 78,
      change: "same",
      tier: "Pro",
      country: "🇩🇪",
    },
    {
      rank: 5,
      name: "FastFingers",
      avatar: "/placeholder.svg?height=40&width=40",
      earnings: "$6,750",
      games: 264,
      winRate: 75,
      change: "up",
      tier: "Pro",
      country: "🇯🇵",
    },
  ]

  const gameSpecificLeaders = {
    chess: [
      { rank: 1, name: "ChessGrandmaster", rating: 2847, games: 156, winRate: 92 },
      { rank: 2, name: "KnightSlayer", rating: 2789, games: 143, winRate: 88 },
      { rank: 3, name: "CheckmateKing", rating: 2734, games: 167, winRate: 85 },
    ],
    puzzle: [
      { rank: 1, name: "PuzzleWizard", rating: 2654, games: 234, winRate: 87 },
      { rank: 2, name: "LogicMaster", rating: 2598, games: 198, winRate: 84 },
      { rank: 3, name: "BrainTeaser", rating: 2543, games: 212, winRate: 81 },
    ],
    word: [
      { rank: 1, name: "WordSmith", rating: 2456, games: 189, winRate: 83 },
      { rank: 2, name: "VocabKing", rating: 2398, games: 176, winRate: 80 },
      { rank: 3, name: "LetterLord", rating: 2334, games: 203, winRate: 78 },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-gradient">SKILLZY</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
            <Link href="/games" className="text-muted-foreground hover:text-foreground transition-colors">
              Games
            </Link>
            <Link href="/tournaments" className="text-muted-foreground hover:text-foreground transition-colors">
              Tournaments
            </Link>
            <Link href="/leaderboard" className="text-foreground font-medium">
              Leaderboard
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Balance</div>
              <div className="font-bold text-primary">$1,247.50</div>
            </div>
            <Button variant="outline" size="sm">
              Profile
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Leaderboards</h1>
          <p className="text-muted-foreground">See who's dominating the arena across all games</p>
        </div>

        {/* Top 3 Podium */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-center">Top Earners This Month</h2>
          <div className="flex items-end justify-center gap-8 max-w-4xl mx-auto">
            {/* 2nd Place */}
            <div className="text-center">
              <div className="relative mb-4">
                <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-2">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={topEarners[1].avatar || "/placeholder.svg"} />
                    <AvatarFallback>{topEarners[1].name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                  <Medal className="w-5 h-5 text-muted-foreground" />
                </div>
              </div>
              <div className="bg-card border border-border/50 rounded-lg p-4 min-h-[120px]">
                <div className="text-lg font-bold mb-1">{topEarners[1].name}</div>
                <div className="text-2xl font-bold text-muted-foreground mb-2">{topEarners[1].earnings}</div>
                <Badge variant="secondary" className="text-xs">
                  {topEarners[1].tier}
                </Badge>
              </div>
            </div>

            {/* 1st Place */}
            <div className="text-center">
              <div className="relative mb-4">
                <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2 glow-effect">
                  <Avatar className="w-20 h-20">
                    <AvatarImage src={topEarners[0].avatar || "/placeholder.svg"} />
                    <AvatarFallback>{topEarners[0].name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute -top-2 -right-2 w-10 h-10 bg-primary rounded-full flex items-center justify-center glow-effect">
                  <Crown className="w-6 h-6 text-primary-foreground" />
                </div>
              </div>
              <div className="bg-card border border-primary/50 rounded-lg p-4 min-h-[140px]">
                <div className="text-xl font-bold mb-1">{topEarners[0].name}</div>
                <div className="text-3xl font-bold text-primary mb-2">{topEarners[0].earnings}</div>
                <Badge className="text-xs pulse-neon">{topEarners[0].tier}</Badge>
              </div>
            </div>

            {/* 3rd Place */}
            <div className="text-center">
              <div className="relative mb-4">
                <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-2">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={topEarners[2].avatar || "/placeholder.svg"} />
                    <AvatarFallback>{topEarners[2].name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center">
                  <Medal className="w-5 h-5 text-accent" />
                </div>
              </div>
              <div className="bg-card border border-border/50 rounded-lg p-4 min-h-[120px]">
                <div className="text-lg font-bold mb-1">{topEarners[2].name}</div>
                <div className="text-2xl font-bold text-accent mb-2">{topEarners[2].earnings}</div>
                <Badge variant="secondary" className="text-xs">
                  {topEarners[2].tier}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Leaderboard Tabs */}
        <Tabs defaultValue="overall" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-full grid-cols-4 lg:w-[500px]">
              <TabsTrigger value="overall">Overall</TabsTrigger>
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
              <TabsTrigger value="games">By Game</TabsTrigger>
              <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
            </TabsList>
            <div className="flex items-center space-x-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Regions</SelectItem>
                  <SelectItem value="na">North America</SelectItem>
                  <SelectItem value="eu">Europe</SelectItem>
                  <SelectItem value="asia">Asia</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Overall Leaderboard */}
          <TabsContent value="overall" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-primary" />
                  Overall Rankings
                </CardTitle>
                <CardDescription>Top players ranked by total earnings and performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topEarners
                    .concat([
                      {
                        rank: 6,
                        name: "EliteGamer",
                        avatar: "/placeholder.svg?height=40&width=40",
                        earnings: "$5,890",
                        games: 245,
                        winRate: 72,
                        change: "up",
                        tier: "Advanced",
                        country: "🇫🇷",
                      },
                      {
                        rank: 7,
                        name: "SkillSeeker",
                        avatar: "/placeholder.svg?height=40&width=40",
                        earnings: "$5,234",
                        games: 231,
                        winRate: 69,
                        change: "down",
                        tier: "Advanced",
                        country: "🇮🇹",
                      },
                      {
                        rank: 8,
                        name: "GameMaster",
                        avatar: "/placeholder.svg?height=40&width=40",
                        earnings: "$4,567",
                        games: 218,
                        winRate: 66,
                        change: "same",
                        tier: "Advanced",
                        country: "🇪🇸",
                      },
                    ])
                    .map((player, index) => (
                      <div
                        key={player.rank}
                        className={`flex items-center justify-between p-4 rounded-lg transition-colors ${
                          player.rank <= 3 ? "bg-primary/5 border border-primary/20" : "hover:bg-muted/50"
                        }`}
                      >
                        <div className="flex items-center space-x-4">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                              player.rank === 1
                                ? "bg-primary text-primary-foreground"
                                : player.rank === 2
                                  ? "bg-muted text-foreground"
                                  : player.rank === 3
                                    ? "bg-accent text-accent-foreground"
                                    : "bg-muted/50 text-muted-foreground"
                            }`}
                          >
                            {player.rank <= 3 ? (
                              player.rank === 1 ? (
                                <Crown className="w-4 h-4" />
                              ) : (
                                <Medal className="w-4 h-4" />
                              )
                            ) : (
                              player.rank
                            )}
                          </div>
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={player.avatar || "/placeholder.svg"} />
                            <AvatarFallback>{player.name.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-semibold">{player.name}</span>
                              <span className="text-lg">{player.country}</span>
                              <Badge variant="outline" className="text-xs">
                                {player.tier}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {player.games} games • {player.winRate}% win rate
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <div className="font-bold text-primary text-lg">{player.earnings}</div>
                            <div className="text-sm text-muted-foreground flex items-center">
                              {player.change === "up" && <ChevronUp className="w-3 h-3 text-primary mr-1" />}
                              {player.change === "down" && <ChevronDown className="w-3 h-3 text-destructive mr-1" />}
                              {player.change === "same" && <Minus className="w-3 h-3 text-muted-foreground mr-1" />}
                              {player.change === "up" ? "Rising" : player.change === "down" ? "Falling" : "Stable"}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Weekly Leaderboard */}
          <TabsContent value="weekly" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-accent" />
                  Weekly Rankings
                </CardTitle>
                <CardDescription>Top performers this week (resets every Monday)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { rank: 1, name: "WeeklyChamp", earnings: "$890", games: 23, winRate: 91, change: "new" },
                    { rank: 2, name: "RisingStart", earnings: "$745", games: 19, winRate: 89, change: "up" },
                    { rank: 3, name: "ConsistentWin", earnings: "$623", games: 21, winRate: 85, change: "same" },
                    { rank: 4, name: "QuickClimber", earnings: "$567", games: 18, winRate: 83, change: "up" },
                    { rank: 5, name: "SteadyPlayer", earnings: "$489", games: 16, winRate: 81, change: "down" },
                  ].map((player, index) => (
                    <div
                      key={player.rank}
                      className="flex items-center justify-between p-4 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center text-sm font-bold text-accent">
                          {player.rank}
                        </div>
                        <div>
                          <div className="font-semibold">{player.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {player.games} games this week • {player.winRate}% win rate
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-accent">{player.earnings}</div>
                        <div className="text-sm text-muted-foreground">
                          {player.change === "new" && (
                            <Badge variant="secondary" className="text-xs">
                              New
                            </Badge>
                          )}
                          {player.change === "up" && <span className="text-primary">↗ Rising</span>}
                          {player.change === "down" && <span className="text-destructive">↘ Falling</span>}
                          {player.change === "same" && <span>→ Stable</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Game-Specific Leaderboards */}
          <TabsContent value="games" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="w-5 h-5 mr-2 text-primary" />
                    Speed Chess
                  </CardTitle>
                  <CardDescription>Top chess players by rating</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {gameSpecificLeaders.chess.map((player) => (
                      <div key={player.rank} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center text-xs font-bold text-primary">
                            {player.rank}
                          </div>
                          <div>
                            <div className="font-medium text-sm">{player.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {player.games} games • {player.winRate}%
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-primary">{player.rating}</div>
                          <div className="text-xs text-muted-foreground">Rating</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Gamepad2 className="w-5 h-5 mr-2 text-accent" />
                    Puzzle Rush
                  </CardTitle>
                  <CardDescription>Top puzzle solvers by rating</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {gameSpecificLeaders.puzzle.map((player) => (
                      <div key={player.rank} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center text-xs font-bold text-accent">
                            {player.rank}
                          </div>
                          <div>
                            <div className="font-medium text-sm">{player.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {player.games} games • {player.winRate}%
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-accent">{player.rating}</div>
                          <div className="text-xs text-muted-foreground">Rating</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="w-5 h-5 mr-2 text-chart-3" />
                    Word Blitz
                  </CardTitle>
                  <CardDescription>Top word game players by rating</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {gameSpecificLeaders.word.map((player) => (
                      <div key={player.rank} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-chart-3/20 rounded-full flex items-center justify-center text-xs font-bold text-chart-3">
                            {player.rank}
                          </div>
                          <div>
                            <div className="font-medium text-sm">{player.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {player.games} games • {player.winRate}%
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-chart-3">{player.rating}</div>
                          <div className="text-xs text-muted-foreground">Rating</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tournament Leaderboard */}
          <TabsContent value="tournaments" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Crown className="w-5 h-5 mr-2 text-primary" />
                  Tournament Champions
                </CardTitle>
                <CardDescription>Players with the most tournament victories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { rank: 1, name: "TournamentKing", wins: 47, earnings: "$15,670", lastWin: "2 days ago" },
                    { rank: 2, name: "ChampionSlayer", wins: 39, earnings: "$12,340", lastWin: "1 week ago" },
                    { rank: 3, name: "VictorySeeker", wins: 34, earnings: "$10,890", lastWin: "3 days ago" },
                    { rank: 4, name: "TitleHolder", wins: 28, earnings: "$8,450", lastWin: "5 days ago" },
                    { rank: 5, name: "WinStreak", wins: 25, earnings: "$7,230", lastWin: "1 day ago" },
                  ].map((player) => (
                    <div
                      key={player.rank}
                      className="flex items-center justify-between p-4 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-sm font-bold text-primary">
                          {player.rank}
                        </div>
                        <div>
                          <div className="font-semibold">{player.name}</div>
                          <div className="text-sm text-muted-foreground">Last win: {player.lastWin}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-primary">{player.wins} wins</div>
                        <div className="text-sm text-muted-foreground">{player.earnings} earned</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
