"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Pause, Bot, Activity, Zap, Clock, CheckCircle, TrendingUp, Wifi, WifiOff } from "lucide-react"

interface AutopilotStatus {
  isActive: boolean
  uptime: number
  matchesProcessed: number
  payoutsProcessed: number
  usersServed: number
  lastActivity: Date
  systemHealth: "excellent" | "good" | "warning" | "critical"
}

interface AutopilotTask {
  id: string
  name: string
  status: "running" | "completed" | "failed" | "pending"
  progress: number
  lastRun: Date
  nextRun: Date
  description: string
}

export default function AutopilotPage() {
  const [autopilotStatus, setAutopilotStatus] = useState<AutopilotStatus>({
    isActive: true,
    uptime: 2847, // minutes
    matchesProcessed: 1247,
    payoutsProcessed: 892,
    usersServed: 3240,
    lastActivity: new Date(),
    systemHealth: "excellent",
  })

  const [autopilotTasks, setAutopilotTasks] = useState<AutopilotTask[]>([
    {
      id: "matchmaking",
      name: "Auto Matchmaking",
      status: "running",
      progress: 85,
      lastRun: new Date(Date.now() - 30000),
      nextRun: new Date(Date.now() + 30000),
      description: "Automatically pair players for matches",
    },
    {
      id: "payouts",
      name: "Payout Processing",
      status: "running",
      progress: 92,
      lastRun: new Date(Date.now() - 15000),
      nextRun: new Date(Date.now() + 45000),
      description: "Process match winnings and wallet updates",
    },
    {
      id: "maintenance",
      name: "System Maintenance",
      status: "completed",
      progress: 100,
      lastRun: new Date(Date.now() - 3600000),
      nextRun: new Date(Date.now() + 3600000),
      description: "Routine system health checks and cleanup",
    },
    {
      id: "analytics",
      name: "Analytics Processing",
      status: "running",
      progress: 67,
      lastRun: new Date(Date.now() - 120000),
      nextRun: new Date(Date.now() + 180000),
      description: "Generate reports and update statistics",
    },
  ])

  const [developerOnline, setDeveloperOnline] = useState(false)
  const [autopilotSettings, setAutopilotSettings] = useState({
    autoMatchmaking: true,
    autoPayouts: true,
    autoMaintenance: true,
    autoSupport: false,
    emergencyShutdown: false,
  })

  // Simulate autopilot activity
  useEffect(() => {
    const interval = setInterval(() => {
      if (autopilotStatus.isActive) {
        setAutopilotStatus((prev) => ({
          ...prev,
          uptime: prev.uptime + 1,
          lastActivity: new Date(),
          matchesProcessed: prev.matchesProcessed + Math.floor(Math.random() * 3),
          payoutsProcessed: prev.payoutsProcessed + Math.floor(Math.random() * 2),
          usersServed: prev.usersServed + Math.floor(Math.random() * 5),
        }))

        // Update task progress
        setAutopilotTasks((prev) =>
          prev.map((task) => {
            if (task.status === "running") {
              const newProgress = Math.min(100, task.progress + Math.random() * 5)
              return {
                ...task,
                progress: newProgress,
                status: newProgress >= 100 ? "completed" : "running",
              }
            }
            return task
          }),
        )
      }
    }, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [autopilotStatus.isActive])

  // Simulate developer online status
  useEffect(() => {
    const statusInterval = setInterval(() => {
      setDeveloperOnline(Math.random() > 0.7) // 30% chance developer is online
    }, 30000)

    return () => clearInterval(statusInterval)
  }, [])

  const toggleAutopilot = () => {
    setAutopilotStatus((prev) => ({
      ...prev,
      isActive: !prev.isActive,
    }))
    console.log(`[v0] Autopilot ${autopilotStatus.isActive ? "disabled" : "enabled"}`)
  }

  const toggleAutopilotFeature = (feature: string, enabled: boolean) => {
    setAutopilotSettings((prev) => ({
      ...prev,
      [feature]: enabled,
    }))
    console.log(`[v0] Autopilot feature ${feature} ${enabled ? "enabled" : "disabled"}`)
  }

  const restartTask = (taskId: string) => {
    setAutopilotTasks((prev) =>
      prev.map((task) =>
        task.id === taskId
          ? {
              ...task,
              status: "running",
              progress: 0,
              lastRun: new Date(),
              nextRun: new Date(Date.now() + 60000),
            }
          : task,
      ),
    )
    console.log(`[v0] Autopilot task ${taskId} restarted`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "text-blue-500"
      case "completed":
        return "text-green-500"
      case "failed":
        return "text-red-500"
      case "pending":
        return "text-yellow-500"
      default:
        return "text-muted-foreground"
    }
  }

  const getHealthColor = (health: string) => {
    switch (health) {
      case "excellent":
        return "text-green-500"
      case "good":
        return "text-blue-500"
      case "warning":
        return "text-yellow-500"
      case "critical":
        return "text-red-500"
      default:
        return "text-muted-foreground"
    }
  }

  const formatUptime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    const days = Math.floor(hours / 24)
    const remainingHours = hours % 24

    if (days > 0) {
      return `${days}d ${remainingHours}h ${mins}m`
    } else if (hours > 0) {
      return `${hours}h ${mins}m`
    } else {
      return `${mins}m`
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold text-gradient">AUTOPILOT CONTROL</span>
              <Badge variant={autopilotStatus.isActive ? "default" : "secondary"} className="ml-2">
                {autopilotStatus.isActive ? <Play className="w-3 h-3 mr-1" /> : <Pause className="w-3 h-3 mr-1" />}
                {autopilotStatus.isActive ? "ACTIVE" : "INACTIVE"}
              </Badge>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Badge variant={developerOnline ? "default" : "secondary"}>
              {developerOnline ? <Wifi className="w-3 h-3 mr-1" /> : <WifiOff className="w-3 h-3 mr-1" />}
              Developer {developerOnline ? "Online" : "Offline"}
            </Badge>
            <Button onClick={toggleAutopilot} variant={autopilotStatus.isActive ? "destructive" : "default"} size="sm">
              {autopilotStatus.isActive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {autopilotStatus.isActive ? "Stop" : "Start"} Autopilot
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-blue-500/20 bg-blue-500/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">System Uptime</div>
                  <div className="text-2xl font-bold text-blue-500">{formatUptime(autopilotStatus.uptime)}</div>
                </div>
                <Clock className="w-8 h-8 text-blue-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Matches Processed</div>
                  <div className="text-2xl font-bold text-green-500">
                    {autopilotStatus.matchesProcessed.toLocaleString()}
                  </div>
                </div>
                <Zap className="w-8 h-8 text-green-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Payouts Processed</div>
                  <div className="text-2xl font-bold text-yellow-500">
                    {autopilotStatus.payoutsProcessed.toLocaleString()}
                  </div>
                </div>
                <TrendingUp className="w-8 h-8 text-yellow-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">System Health</div>
                  <div className={`text-2xl font-bold capitalize ${getHealthColor(autopilotStatus.systemHealth)}`}>
                    {autopilotStatus.systemHealth}
                  </div>
                </div>
                <Activity className={`w-8 h-8 ${getHealthColor(autopilotStatus.systemHealth)}/20`} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Control Tabs */}
        <Tabs defaultValue="tasks" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="tasks">Active Tasks</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="logs">Activity Logs</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="tasks" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {autopilotTasks.map((task) => (
                <Card key={task.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{task.name}</span>
                      <Badge variant={task.status === "running" ? "default" : "secondary"}>
                        <div className={`w-2 h-2 rounded-full mr-2 ${getStatusColor(task.status)}`} />
                        {task.status}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{task.description}</p>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{task.progress}%</span>
                      </div>
                      <Progress value={task.progress} />
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Last Run</div>
                        <div>{task.lastRun.toLocaleTimeString()}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Next Run</div>
                        <div>{task.nextRun.toLocaleTimeString()}</div>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => restartTask(task.id)}
                      disabled={task.status === "running"}
                      className="w-full"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Restart Task
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Autopilot Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Auto Matchmaking</div>
                    <div className="text-sm text-muted-foreground">Automatically pair players and start matches</div>
                  </div>
                  <Switch
                    checked={autopilotSettings.autoMatchmaking}
                    onCheckedChange={(checked) => toggleAutopilotFeature("autoMatchmaking", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Auto Payouts</div>
                    <div className="text-sm text-muted-foreground">
                      Process winnings and wallet updates automatically
                    </div>
                  </div>
                  <Switch
                    checked={autopilotSettings.autoPayouts}
                    onCheckedChange={(checked) => toggleAutopilotFeature("autoPayouts", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Auto Maintenance</div>
                    <div className="text-sm text-muted-foreground">Perform routine system maintenance tasks</div>
                  </div>
                  <Switch
                    checked={autopilotSettings.autoMaintenance}
                    onCheckedChange={(checked) => toggleAutopilotFeature("autoMaintenance", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Emergency Shutdown</div>
                    <div className="text-sm text-muted-foreground">
                      Automatically shutdown system if critical issues detected
                    </div>
                  </div>
                  <Switch
                    checked={autopilotSettings.emergencyShutdown}
                    onCheckedChange={(checked) => toggleAutopilotFeature("emergencyShutdown", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      time: new Date(Date.now() - 120000),
                      action: "Processed match payout",
                      details: "₹16 credited to user wallet",
                      status: "success",
                    },
                    {
                      time: new Date(Date.now() - 180000),
                      action: "Auto-matched players",
                      details: "Chess match started between 2 players",
                      status: "success",
                    },
                    {
                      time: new Date(Date.now() - 300000),
                      action: "System health check",
                      details: "All systems operational",
                      status: "success",
                    },
                    {
                      time: new Date(Date.now() - 420000),
                      action: "Database cleanup",
                      details: "Removed expired session data",
                      status: "success",
                    },
                  ].map((log, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <div>
                          <div className="font-semibold">{log.action}</div>
                          <div className="text-sm text-muted-foreground">{log.details}</div>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground">{log.time.toLocaleTimeString()}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>System Resources</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>CPU Usage</span>
                      <span>23%</span>
                    </div>
                    <Progress value={23} />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Memory Usage</span>
                      <span>45%</span>
                    </div>
                    <Progress value={45} />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Database Load</span>
                      <span>12%</span>
                    </div>
                    <Progress value={12} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Average Response Time</span>
                    <Badge variant="secondary">45ms</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Success Rate</span>
                    <Badge variant="default" className="bg-green-500/20 text-green-500">
                      99.8%
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Active Connections</span>
                    <Badge variant="secondary">3,240</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Queue Length</span>
                    <Badge variant="secondary">12</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
