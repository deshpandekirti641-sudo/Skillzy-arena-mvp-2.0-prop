"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  Wallet,
  Plus,
  Minus,
  ArrowUpRight,
  ArrowDownLeft,
  CreditCard,
  Smartphone,
  Building2,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Zap,
  Trophy,
  TrendingUp,
  History,
} from "lucide-react"
import Link from "next/link"

interface Transaction {
  id: string
  type: "deposit" | "withdrawal" | "bet" | "win" | "server_fee"
  amount: number
  status: "pending" | "completed" | "failed"
  timestamp: Date
  description: string
  gameId?: string
}

export default function WalletPage() {
  const [balance, setBalance] = useState(1250)
  const [depositAmount, setDepositAmount] = useState("")
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("")
  const [upiId, setUpiId] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: "txn_001",
      type: "win",
      amount: 16,
      status: "completed",
      timestamp: new Date(Date.now() - 300000),
      description: "Won Chess match vs ProPlayer",
      gameId: "chess",
    },
    {
      id: "txn_002",
      type: "bet",
      amount: -10,
      status: "completed",
      timestamp: new Date(Date.now() - 600000),
      description: "Bet placed on Carrom match",
      gameId: "carrom",
    },
    {
      id: "txn_003",
      type: "server_fee",
      amount: -4,
      status: "completed",
      timestamp: new Date(Date.now() - 600000),
      description: "Server fee for match",
      gameId: "carrom",
    },
    {
      id: "txn_004",
      type: "deposit",
      amount: 500,
      status: "completed",
      timestamp: new Date(Date.now() - 3600000),
      description: "UPI deposit via PhonePe",
    },
  ])

  const handleDeposit = async () => {
    const amount = Number.parseFloat(depositAmount)
    if (amount < 10 || amount > 2000) {
      alert("Deposit amount must be between ₹10 and ₹2000")
      return
    }

    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      const newTransaction: Transaction = {
        id: `txn_${Date.now()}`,
        type: "deposit",
        amount: amount,
        status: "completed",
        timestamp: new Date(),
        description: `${paymentMethod} deposit`,
      }

      setTransactions((prev) => [newTransaction, ...prev])
      setBalance((prev) => prev + amount)
      setDepositAmount("")
      setIsProcessing(false)

      console.log("[v0] Deposit processed successfully:", amount)
    }, 2000)
  }

  const handleWithdrawal = async () => {
    const amount = Number.parseFloat(withdrawAmount)
    if (amount < 10 || amount > 2000) {
      alert("Withdrawal amount must be between ₹10 and ₹2000")
      return
    }

    if (amount > balance) {
      alert("Insufficient balance")
      return
    }

    setIsProcessing(true)

    // Simulate withdrawal processing
    setTimeout(() => {
      const newTransaction: Transaction = {
        id: `txn_${Date.now()}`,
        type: "withdrawal",
        amount: -amount,
        status: "pending",
        timestamp: new Date(),
        description: `Withdrawal to ${paymentMethod}`,
      }

      setTransactions((prev) => [newTransaction, ...prev])
      setBalance((prev) => prev - amount)
      setWithdrawAmount("")
      setIsProcessing(false)

      console.log("[v0] Withdrawal initiated:", amount)
    }, 2000)
  }

  // Simulate automatic match transactions
  const simulateMatchTransaction = (gameType: string, isWin: boolean) => {
    const betTransaction: Transaction = {
      id: `txn_${Date.now()}_bet`,
      type: "bet",
      amount: -10,
      status: "completed",
      timestamp: new Date(),
      description: `Bet placed on ${gameType} match`,
      gameId: gameType.toLowerCase(),
    }

    const serverFeeTransaction: Transaction = {
      id: `txn_${Date.now()}_fee`,
      type: "server_fee",
      amount: -4,
      status: "completed",
      timestamp: new Date(),
      description: "Server fee deducted",
      gameId: gameType.toLowerCase(),
    }

    setTransactions((prev) => [serverFeeTransaction, betTransaction, ...prev])
    setBalance((prev) => prev - 14) // 10 bet + 4 server fee

    if (isWin) {
      setTimeout(() => {
        const winTransaction: Transaction = {
          id: `txn_${Date.now()}_win`,
          type: "win",
          amount: 16,
          status: "completed",
          timestamp: new Date(),
          description: `Won ${gameType} match - Prize money`,
          gameId: gameType.toLowerCase(),
        }

        setTransactions((prev) => [winTransaction, ...prev])
        setBalance((prev) => prev + 16)

        console.log("[v0] Match win processed - ₹16 credited to wallet")
      }, 1000)
    }
  }

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownLeft className="w-4 h-4 text-green-500" />
      case "withdrawal":
        return <ArrowUpRight className="w-4 h-4 text-red-500" />
      case "win":
        return <Trophy className="w-4 h-4 text-yellow-500" />
      case "bet":
        return <Minus className="w-4 h-4 text-blue-500" />
      case "server_fee":
        return <Building2 className="w-4 h-4 text-gray-500" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-500" />
      case "failed":
        return <XCircle className="w-4 h-4 text-red-500" />
      default:
        return <AlertCircle className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-gradient">SKILLZY</span>
            </Link>
            <Badge variant="secondary" className="pulse-neon">
              <Wallet className="w-3 h-3 mr-1" />
              Wallet
            </Badge>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="/games">
              <Button variant="ghost" size="sm">
                Back to Games
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Wallet Balance Card */}
        <Card className="mb-8 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                    <Wallet className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-muted-foreground">Wallet Balance</h2>
                    <div className="text-4xl font-bold text-primary">₹{balance.toLocaleString()}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    Available for withdrawal
                  </div>
                </div>
              </div>

              <div className="flex flex-col space-y-3">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="glow-effect">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Money
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Money to Wallet</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="deposit-amount">Amount (₹10 - ₹2000)</Label>
                        <Input
                          id="deposit-amount"
                          type="number"
                          placeholder="Enter amount"
                          value={depositAmount}
                          onChange={(e) => setDepositAmount(e.target.value)}
                          min="10"
                          max="2000"
                        />
                      </div>

                      <div>
                        <Label htmlFor="payment-method">Payment Method</Label>
                        <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select payment method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="upi">
                              <div className="flex items-center">
                                <Smartphone className="w-4 h-4 mr-2" />
                                UPI
                              </div>
                            </SelectItem>
                            <SelectItem value="netbanking">
                              <div className="flex items-center">
                                <Building2 className="w-4 h-4 mr-2" />
                                Net Banking
                              </div>
                            </SelectItem>
                            <SelectItem value="card">
                              <div className="flex items-center">
                                <CreditCard className="w-4 h-4 mr-2" />
                                Debit/Credit Card
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {paymentMethod === "upi" && (
                        <div>
                          <Label htmlFor="upi-id">UPI ID</Label>
                          <Input
                            id="upi-id"
                            placeholder="yourname@upi"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                          />
                        </div>
                      )}

                      <Button
                        onClick={handleDeposit}
                        disabled={isProcessing || !depositAmount || !paymentMethod}
                        className="w-full"
                      >
                        {isProcessing ? "Processing..." : `Add ₹${depositAmount || 0}`}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <Minus className="w-4 h-4 mr-2" />
                      Withdraw
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Withdraw Money</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="withdraw-amount">Amount (₹10 - ₹2000)</Label>
                        <Input
                          id="withdraw-amount"
                          type="number"
                          placeholder="Enter amount"
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          min="10"
                          max="2000"
                        />
                        <div className="text-sm text-muted-foreground mt-1">Available: ₹{balance.toLocaleString()}</div>
                      </div>

                      <div>
                        <Label htmlFor="withdraw-method">Withdrawal Method</Label>
                        <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select withdrawal method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="upi">
                              <div className="flex items-center">
                                <Smartphone className="w-4 h-4 mr-2" />
                                UPI
                              </div>
                            </SelectItem>
                            <SelectItem value="bank">
                              <div className="flex items-center">
                                <Building2 className="w-4 h-4 mr-2" />
                                Bank Transfer
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Button
                        onClick={handleWithdrawal}
                        disabled={isProcessing || !withdrawAmount || !paymentMethod}
                        className="w-full"
                      >
                        {isProcessing ? "Processing..." : `Withdraw ₹${withdrawAmount || 0}`}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Today's Earnings</div>
                  <div className="text-2xl font-bold text-green-500">₹48</div>
                </div>
                <Trophy className="w-8 h-8 text-green-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Games Played</div>
                  <div className="text-2xl font-bold text-blue-500">12</div>
                </div>
                <Zap className="w-8 h-8 text-blue-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Win Rate</div>
                  <div className="text-2xl font-bold text-yellow-500">75%</div>
                </div>
                <TrendingUp className="w-8 h-8 text-yellow-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Total Withdrawn</div>
                  <div className="text-2xl font-bold text-purple-500">₹2,340</div>
                </div>
                <ArrowUpRight className="w-8 h-8 text-purple-500/20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <History className="w-5 h-5 mr-2" />
              Transaction History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    {getTransactionIcon(transaction.type)}
                    <div>
                      <div className="font-semibold">{transaction.description}</div>
                      <div className="text-sm text-muted-foreground">{transaction.timestamp.toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className={`font-bold ${transaction.amount > 0 ? "text-green-500" : "text-red-500"}`}>
                        {transaction.amount > 0 ? "+" : ""}₹{Math.abs(transaction.amount)}
                      </div>
                      <div className="text-sm text-muted-foreground capitalize">
                        {transaction.type.replace("_", " ")}
                      </div>
                    </div>
                    {getStatusIcon(transaction.status)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Test Match Simulation */}
        <Card className="mt-8 border-dashed border-2 border-muted-foreground/20">
          <CardHeader>
            <CardTitle className="text-muted-foreground">Test Match Simulation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button variant="outline" onClick={() => simulateMatchTransaction("Chess", true)}>
                Simulate Chess Win
              </Button>
              <Button variant="outline" onClick={() => simulateMatchTransaction("Carrom", false)}>
                Simulate Carrom Loss
              </Button>
              <Button variant="outline" onClick={() => simulateMatchTransaction("Snake & Ladder", true)}>
                Simulate Snake & Ladder Win
              </Button>
            </div>
            <div className="text-sm text-muted-foreground mt-2">
              Test the automatic wallet transactions for match betting and payouts
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
