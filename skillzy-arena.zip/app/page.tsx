import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Trophy, DollarSign, Users, Zap, Star, Play, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-gradient">SKILLZY</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="#games" className="text-muted-foreground hover:text-foreground transition-colors">
              Games
            </Link>
            <Link href="#leaderboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Leaderboard
            </Link>
            <Link href="#earnings" className="text-muted-foreground hover:text-foreground transition-colors">
              Earnings
            </Link>
            <Link href="#how-it-works" className="text-muted-foreground hover:text-foreground transition-colors">
              How it Works
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Link href="/login">
              <Button variant="ghost" size="sm">
                Login
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="glow-effect">
                Sign Up <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="container mx-auto px-4 py-20 relative">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 pulse-neon" variant="secondary">
              <Star className="w-3 h-3 mr-1" />
              Real Money Gaming Platform
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-balance">
              Compete in the
              <span className="text-gradient block">Ultimate Arena</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
              Turn your gaming skills into real earnings. Compete against players worldwide in skill-based games and
              climb the leaderboards.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Link href="/signup">
                <Button size="lg" className="glow-effect text-lg px-8">
                  <Play className="w-5 h-5 mr-2" />
                  Start Playing
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg px-8 bg-transparent">
                Watch Demo
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">$2.4M+</div>
                <div className="text-muted-foreground">Total Earnings Paid</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">50K+</div>
                <div className="text-muted-foreground">Active Players</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-chart-3 mb-2">24/7</div>
                <div className="text-muted-foreground">Live Tournaments</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section id="games" className="py-20 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Games</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Master these skill-based games and compete for real money prizes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Carrom Master",
                description: "Strategic board game with precise shots and skill",
                prize: "₹16",
                players: "1.2K",
                difficulty: "Medium",
                image: "/carrom-board-neon.jpg",
              },
              {
                title: "Speed Chess",
                description: "Fast-paced chess matches with real-time betting",
                prize: "₹16",
                players: "2.1K",
                difficulty: "Expert",
                image: "/chess-board-neon-gaming.jpg",
              },
              {
                title: "Snake & Ladder Rush",
                description: "Classic board game with modern competitive twists",
                prize: "₹16",
                players: "3.5K",
                difficulty: "Easy",
                image: "/snake-ladder-neon.jpg",
              },
            ].map((game, index) => (
              <Card key={index} className="group hover:border-primary/50 transition-all duration-300 overflow-hidden">
                <div className="aspect-video bg-muted relative overflow-hidden">
                  <img
                    src={game.image || "/placeholder.svg"}
                    alt={game.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 right-3">
                    <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
                      {game.prize} Win
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-semibold">{game.title}</h3>
                    <Badge
                      variant={
                        game.difficulty === "Expert"
                          ? "destructive"
                          : game.difficulty === "Medium"
                            ? "default"
                            : "secondary"
                      }
                    >
                      {game.difficulty}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground mb-4">{game.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Users className="w-4 h-4 mr-1" />
                      {game.players} playing
                    </div>
                    <Link href="/games">
                      <Button size="sm" className="group-hover:glow-effect">
                        Play Now
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/games">
              <Button size="lg" className="glow-effect">
                <Play className="w-5 h-5 mr-2" />
                View All Games
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Simple steps to start earning money with your gaming skills
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                step: "01",
                title: "Create Account",
                description: "Sign up and verify your identity to start playing",
                icon: Users,
              },
              {
                step: "02",
                title: "Choose Game",
                description: "Select from our skill-based games and join tournaments",
                icon: Trophy,
              },
              {
                step: "03",
                title: "Win & Earn",
                description: "Compete against others and withdraw your winnings instantly",
                icon: DollarSign,
              },
            ].map((item, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/30 transition-colors">
                  <item.icon className="w-8 h-8 text-primary" />
                </div>
                <div className="text-sm font-mono text-primary mb-2">{item.step}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leaderboard Preview */}
      <section id="leaderboard" className="py-20 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Top Earners</h2>
            <p className="text-muted-foreground text-lg">See who's dominating the arena this week</p>
          </div>

          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <div className="space-y-4">
                {[
                  { rank: 1, name: "ProGamer_X", earnings: "$2,450", games: 127, badge: "🥇" },
                  { rank: 2, name: "SkillMaster", earnings: "$1,890", games: 98, badge: "🥈" },
                  { rank: 3, name: "QuickWin", earnings: "$1,340", games: 85, badge: "🥉" },
                  { rank: 4, name: "GameChamp", earnings: "$980", games: 72, badge: "" },
                  { rank: 5, name: "FastFingers", earnings: "$750", games: 64, badge: "" },
                ].map((player) => (
                  <div
                    key={player.rank}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-sm font-bold">
                        {player.badge || player.rank}
                      </div>
                      <div>
                        <div className="font-semibold">{player.name}</div>
                        <div className="text-sm text-muted-foreground">{player.games} games played</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-primary">{player.earnings}</div>
                      <div className="text-sm text-muted-foreground flex items-center">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        This week
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20" />
        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-balance">
              Ready to Turn Your Skills Into
              <span className="text-gradient block">Real Money?</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join thousands of players already earning money through competitive gaming
            </p>
            <Link href="/signup">
              <Button size="lg" className="glow-effect text-lg px-12 py-6">
                <Play className="w-5 h-5 mr-2" />
                Start Playing Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-gradient">SKILLZY</span>
              </div>
              <p className="text-muted-foreground">
                The ultimate platform for skill-based gaming and real money competitions.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Games</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Speed Chess
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Puzzle Rush
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Word Blitz
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Leaderboard
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Tournaments
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Earnings
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 Skillzy Arena. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
