"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Smartphone, Mail, Shield, Clock, CheckCircle, ArrowRight, Zap, AlertCircle } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AuthPage() {
  const [authMethod, setAuthMethod] = useState<"mobile" | "email">("mobile")
  const [step, setStep] = useState<"input" | "verify" | "success">("input")
  const [mobileNumber, setMobileNumber] = useState("")
  const [email, setEmail] = useState("")
  const [otp, setOtp] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [countdown, setCountdown] = useState(0)
  const [generatedOtp, setGeneratedOtp] = useState("")
  const router = useRouter()

  // Countdown timer for resend OTP
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (countdown > 0) {
      interval = setInterval(() => {
        setCountdown((prev) => prev - 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [countdown])

  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const sendOTP = async () => {
    setIsLoading(true)

    // Generate and store OTP for simulation
    const newOtp = generateOTP()
    setGeneratedOtp(newOtp)

    // Simulate API call delay
    setTimeout(() => {
      setIsLoading(false)
      setStep("verify")
      setCountdown(60)

      // In real implementation, this would be sent via SMS/Email
      console.log(`[v0] OTP sent to ${authMethod === "mobile" ? mobileNumber : email}: ${newOtp}`)

      // Show OTP in alert for demo purposes
      alert(`Demo OTP: ${newOtp} (In production, this would be sent via ${authMethod === "mobile" ? "SMS" : "Email"})`)
    }, 2000)
  }

  const verifyOTP = async () => {
    if (otp !== generatedOtp) {
      alert("Invalid OTP. Please try again.")
      return
    }

    setIsLoading(true)

    // Simulate verification delay
    setTimeout(() => {
      setIsLoading(false)
      setStep("success")

      // Auto redirect after success
      setTimeout(() => {
        router.push("/dashboard")
      }, 2000)
    }, 1500)
  }

  const resendOTP = () => {
    if (countdown > 0) return

    const newOtp = generateOTP()
    setGeneratedOtp(newOtp)
    setCountdown(60)

    console.log(`[v0] OTP resent to ${authMethod === "mobile" ? mobileNumber : email}: ${newOtp}`)
    alert(`Demo OTP: ${newOtp} (Resent)`)
  }

  const validateInput = () => {
    if (authMethod === "mobile") {
      return mobileNumber.length === 10 && /^\d+$/.test(mobileNumber)
    } else {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold text-gradient">SKILLZY</span>
          </Link>
          <h1 className="text-2xl font-bold mb-2">Welcome to Skillzy Arena</h1>
          <p className="text-muted-foreground">
            {step === "input" && "Enter your details to get started"}
            {step === "verify" && "Verify your identity with OTP"}
            {step === "success" && "Authentication successful!"}
          </p>
        </div>

        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center justify-center space-x-2">
              <Shield className="w-5 h-5 text-primary" />
              <span>Secure Authentication</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {step === "input" && (
              <>
                <Tabs value={authMethod} onValueChange={(value) => setAuthMethod(value as "mobile" | "email")}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="mobile" className="flex items-center space-x-2">
                      <Smartphone className="w-4 h-4" />
                      <span>Mobile</span>
                    </TabsTrigger>
                    <TabsTrigger value="email" className="flex items-center space-x-2">
                      <Mail className="w-4 h-4" />
                      <span>Email</span>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="mobile" className="space-y-4">
                    <div>
                      <Label htmlFor="mobile">Mobile Number</Label>
                      <div className="flex">
                        <div className="flex items-center px-3 border border-r-0 border-input rounded-l-md bg-muted">
                          <span className="text-sm">+91</span>
                        </div>
                        <Input
                          id="mobile"
                          type="tel"
                          placeholder="Enter 10-digit mobile number"
                          value={mobileNumber}
                          onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                          className="rounded-l-none"
                          maxLength={10}
                        />
                      </div>
                      {mobileNumber && mobileNumber.length !== 10 && (
                        <p className="text-sm text-destructive mt-1">Please enter a valid 10-digit mobile number</p>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="email" className="space-y-4">
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                      {email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && (
                        <p className="text-sm text-destructive mt-1">Please enter a valid email address</p>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>

                <Button onClick={sendOTP} disabled={!validateInput() || isLoading} className="w-full glow-effect">
                  {isLoading ? (
                    <>
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      Sending OTP...
                    </>
                  ) : (
                    <>
                      <ArrowRight className="w-4 h-4 mr-2" />
                      Send OTP
                    </>
                  )}
                </Button>

                <div className="text-center text-sm text-muted-foreground">
                  <p>By continuing, you agree to our Terms of Service and Privacy Policy</p>
                </div>
              </>
            )}

            {step === "verify" && (
              <>
                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">
                    Verify Your {authMethod === "mobile" ? "Mobile Number" : "Email"}
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    We've sent a 6-digit OTP to{" "}
                    <span className="font-semibold text-foreground">
                      {authMethod === "mobile" ? `+91 ${mobileNumber}` : email}
                    </span>
                  </p>
                </div>

                <div>
                  <Label htmlFor="otp">Enter OTP</Label>
                  <Input
                    id="otp"
                    type="text"
                    placeholder="Enter 6-digit OTP"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    maxLength={6}
                    className="text-center text-lg tracking-widest"
                  />
                </div>

                <Button onClick={verifyOTP} disabled={otp.length !== 6 || isLoading} className="w-full glow-effect">
                  {isLoading ? (
                    <>
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Verify OTP
                    </>
                  )}
                </Button>

                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-2">Didn't receive the OTP?</p>
                  <Button
                    variant="ghost"
                    onClick={resendOTP}
                    disabled={countdown > 0}
                    className="text-primary hover:text-primary/80"
                  >
                    {countdown > 0 ? `Resend in ${countdown}s` : "Resend OTP"}
                  </Button>
                </div>

                <Button
                  variant="outline"
                  onClick={() => {
                    setStep("input")
                    setOtp("")
                    setCountdown(0)
                  }}
                  className="w-full"
                >
                  Change {authMethod === "mobile" ? "Mobile Number" : "Email"}
                </Button>
              </>
            )}

            {step === "success" && (
              <div className="text-center space-y-6">
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-10 h-10 text-green-500" />
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-green-500 mb-2">Authentication Successful!</h3>
                  <p className="text-muted-foreground">
                    Your {authMethod === "mobile" ? "mobile number" : "email"} has been verified successfully.
                  </p>
                </div>

                <div className="space-y-3">
                  <Badge variant="secondary" className="bg-green-500/20 text-green-500 border-green-500/30">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Account Verified
                  </Badge>

                  <div className="text-sm text-muted-foreground">
                    <p>Redirecting to dashboard...</p>
                    <div className="w-full bg-muted rounded-full h-2 mt-2">
                      <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: "100%" }}></div>
                    </div>
                  </div>
                </div>

                <Link href="/dashboard">
                  <Button className="w-full glow-effect">
                    <ArrowRight className="w-4 h-4 mr-2" />
                    Continue to Dashboard
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Features */}
        <Card className="mt-6 border-dashed border-2 border-muted-foreground/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <Shield className="w-5 h-5 text-primary" />
              <h4 className="font-semibold">Security Features</h4>
            </div>
            <div className="grid grid-cols-1 gap-2 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>OTP-based verification</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Secure mobile & email authentication</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Real-time verification system</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Auto-expiring OTP codes</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Developer Access Note */}
        <Card className="mt-4 bg-muted/30 border-muted-foreground/20">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-yellow-500 mb-1">Developer Access</p>
                <p className="text-muted-foreground">
                  Developer access is restricted to mobile: 8976096360 and email: deshpandekirti641@gmail.com with
                  special OTP verification.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
