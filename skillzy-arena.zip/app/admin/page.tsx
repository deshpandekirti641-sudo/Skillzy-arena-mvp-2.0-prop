"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  Users,
  Wallet,
  TrendingUp,
  Shield,
  Play,
  Pause,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle,
  Activity,
  Database,
  Crown,
  Eye,
  EyeOff,
  RefreshCw,
} from "lucide-react"

interface SystemStats {
  totalUsers: number
  activeUsers: number
  totalMatches: number
  totalRevenue: number
  developerWallet: number
  serverUptime: string
  autopilotStatus: boolean
}

interface UserData {
  id: string
  name: string
  mobile: string
  email: string
  walletBalance: number
  gamesPlayed: number
  winRate: number
  status: "active" | "suspended" | "banned"
  joinedDate: Date
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authStep, setAuthStep] = useState<"login" | "otp">("login")
  const [adminCredentials, setAdminCredentials] = useState({ mobile: "", email: "", otp: "" })
  const [systemStats, setSystemStats] = useState<SystemStats>({
    totalUsers: 15420,
    activeUsers: 3240,
    totalMatches: 89650,
    totalRevenue: 2450000,
    developerWallet: 245000,
    serverUptime: "99.8%",
    autopilotStatus: true,
  })

  const [users, setUsers] = useState<UserData[]>([
    {
      id: "1",
      name: "ProGamer_X",
      mobile: "9876543210",
      email: "progamer@example.com",
      walletBalance: 2450,
      gamesPlayed: 127,
      winRate: 78.5,
      status: "active",
      joinedDate: new Date("2024-01-15"),
    },
    {
      id: "2",
      name: "SkillMaster",
      mobile: "9876543211",
      email: "skillmaster@example.com",
      walletBalance: 1890,
      gamesPlayed: 98,
      winRate: 82.1,
      status: "active",
      joinedDate: new Date("2024-02-20"),
    },
  ])

  const [autopilotSettings, setAutopilotSettings] = useState({
    enabled: true,
    matchmaking: true,
    payoutProcessing: true,
    userSupport: false,
    maintenanceMode: false,
  })

  const [showDeveloperWallet, setShowDeveloperWallet] = useState(false)

  const authenticateAdmin = () => {
    const { mobile, email } = adminCredentials

    // Check if credentials match developer access
    if (mobile === "8976096360" || email === "deshpandekirti641@gmail.com") {
      setAuthStep("otp")
      // Simulate OTP generation
      const otp = "123456" // In production, this would be sent via SMS/Email
      console.log(`[v0] Admin OTP generated: ${otp}`)
      alert(`Admin OTP: ${otp} (Demo)`)
    } else {
      alert("Unauthorized access. Only developer can access this panel.")
    }
  }

  const verifyAdminOTP = () => {
    if (adminCredentials.otp === "123456") {
      setIsAuthenticated(true)
      console.log("[v0] Admin authenticated successfully")
    } else {
      alert("Invalid OTP. Access denied.")
    }
  }

  const toggleAutopilot = (feature: string, enabled: boolean) => {
    setAutopilotSettings((prev) => ({
      ...prev,
      [feature]: enabled,
    }))
    console.log(`[v0] Autopilot ${feature} ${enabled ? "enabled" : "disabled"}`)
  }

  const withdrawFromDeveloperWallet = (amount: number) => {
    if (amount > systemStats.developerWallet) {
      alert("Insufficient funds in developer wallet")
      return
    }

    setSystemStats((prev) => ({
      ...prev,
      developerWallet: prev.developerWallet - amount,
    }))

    console.log(`[v0] Developer withdrawal: ₹${amount}`)
    alert(`₹${amount} withdrawn from developer wallet`)
  }

  const suspendUser = (userId: string) => {
    setUsers((prev) => prev.map((user) => (user.id === userId ? { ...user, status: "suspended" as const } : user)))
    console.log(`[v0] User ${userId} suspended`)
  }

  const reactivateUser = (userId: string) => {
    setUsers((prev) => prev.map((user) => (user.id === userId ? { ...user, status: "active" as const } : user)))
    console.log(`[v0] User ${userId} reactivated`)
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-destructive/20">
          <CardHeader>
            <CardTitle className="flex items-center justify-center space-x-2 text-destructive">
              <Shield className="w-6 h-6" />
              <span>Developer Access Only</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {authStep === "login" && (
              <>
                <div>
                  <Label htmlFor="admin-mobile">Developer Mobile</Label>
                  <Input
                    id="admin-mobile"
                    placeholder="8976096360"
                    value={adminCredentials.mobile}
                    onChange={(e) => setAdminCredentials((prev) => ({ ...prev, mobile: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="admin-email">Developer Email</Label>
                  <Input
                    id="admin-email"
                    placeholder="deshpandekirti641@gmail.com"
                    value={adminCredentials.email}
                    onChange={(e) => setAdminCredentials((prev) => ({ ...prev, email: e.target.value }))}
                  />
                </div>

                <Button onClick={authenticateAdmin} className="w-full">
                  <Shield className="w-4 h-4 mr-2" />
                  Authenticate
                </Button>
              </>
            )}

            {authStep === "otp" && (
              <>
                <div className="text-center mb-4">
                  <p className="text-sm text-muted-foreground">OTP sent to developer credentials</p>
                </div>

                <div>
                  <Label htmlFor="admin-otp">Enter OTP</Label>
                  <Input
                    id="admin-otp"
                    placeholder="Enter 6-digit OTP"
                    value={adminCredentials.otp}
                    onChange={(e) => setAdminCredentials((prev) => ({ ...prev, otp: e.target.value }))}
                    maxLength={6}
                  />
                </div>

                <Button onClick={verifyAdminOTP} className="w-full">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Verify & Access
                </Button>
              </>
            )}

            <div className="text-center text-sm text-muted-foreground">
              <AlertTriangle className="w-4 h-4 inline mr-1" />
              Restricted to authorized developer only
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-destructive rounded-lg flex items-center justify-center">
              <Crown className="w-5 h-5 text-destructive-foreground" />
            </div>
            <div>
              <span className="text-xl font-bold text-gradient">SKILLZY ADMIN</span>
              <Badge variant="destructive" className="ml-2">
                Developer Panel
              </Badge>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Badge variant={autopilotSettings.enabled ? "default" : "secondary"}>
              {autopilotSettings.enabled ? <Play className="w-3 h-3 mr-1" /> : <Pause className="w-3 h-3 mr-1" />}
              Autopilot {autopilotSettings.enabled ? "ON" : "OFF"}
            </Badge>
            <Button variant="outline" size="sm" onClick={() => setIsAuthenticated(false)}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* System Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Total Users</div>
                  <div className="text-2xl font-bold text-primary">{systemStats.totalUsers.toLocaleString()}</div>
                </div>
                <Users className="w-8 h-8 text-primary/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Active Now</div>
                  <div className="text-2xl font-bold text-green-500">{systemStats.activeUsers.toLocaleString()}</div>
                </div>
                <Activity className="w-8 h-8 text-green-500/20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Total Revenue</div>
                  <div className="text-2xl font-bold text-accent">
                    ₹{(systemStats.totalRevenue / 100000).toFixed(1)}L
                  </div>
                </div>
                <TrendingUp className="w-8 h-8 text-accent/20" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-yellow-500/20 bg-yellow-500/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground flex items-center">
                    Developer Wallet
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDeveloperWallet(!showDeveloperWallet)}
                      className="ml-2 h-auto p-1"
                    >
                      {showDeveloperWallet ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    </Button>
                  </div>
                  <div className="text-2xl font-bold text-yellow-500">
                    {showDeveloperWallet ? `₹${(systemStats.developerWallet / 1000).toFixed(0)}K` : "₹***K"}
                  </div>
                </div>
                <Wallet className="w-8 h-8 text-yellow-500/20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Control Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="autopilot">Autopilot</TabsTrigger>
            <TabsTrigger value="wallet">Dev Wallet</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Live Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Matches Today</span>
                    <Badge variant="secondary">1,247</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Server Uptime</span>
                    <Badge variant="default">{systemStats.serverUptime}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Revenue Today</span>
                    <Badge variant="secondary">₹12,450</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Active Games</span>
                    <Badge variant="default">3 Games</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Database</span>
                    <Badge variant="default" className="bg-green-500/20 text-green-500">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Healthy
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Payment Gateway</span>
                    <Badge variant="default" className="bg-green-500/20 text-green-500">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Online
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Game Servers</span>
                    <Badge variant="default" className="bg-green-500/20 text-green-500">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Running
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Autopilot</span>
                    <Badge variant={autopilotSettings.enabled ? "default" : "secondary"}>
                      {autopilotSettings.enabled ? (
                        <Play className="w-3 h-3 mr-1" />
                      ) : (
                        <Pause className="w-3 h-3 mr-1" />
                      )}
                      {autopilotSettings.enabled ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between p-4 border border-border rounded-lg"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-semibold">{user.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {user.mobile} • {user.email}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            ₹{user.walletBalance} • {user.gamesPlayed} games • {user.winRate}% win rate
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={
                            user.status === "active"
                              ? "default"
                              : user.status === "suspended"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {user.status}
                        </Badge>

                        {user.status === "active" ? (
                          <Button variant="outline" size="sm" onClick={() => suspendUser(user.id)}>
                            Suspend
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm" onClick={() => reactivateUser(user.id)}>
                            Reactivate
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="autopilot" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Autopilot Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Master Autopilot</div>
                    <div className="text-sm text-muted-foreground">Enable/disable all automated systems</div>
                  </div>
                  <Switch
                    checked={autopilotSettings.enabled}
                    onCheckedChange={(checked) => toggleAutopilot("enabled", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Auto Matchmaking</div>
                    <div className="text-sm text-muted-foreground">Automatically pair players for matches</div>
                  </div>
                  <Switch
                    checked={autopilotSettings.matchmaking}
                    onCheckedChange={(checked) => toggleAutopilot("matchmaking", checked)}
                    disabled={!autopilotSettings.enabled}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Auto Payout Processing</div>
                    <div className="text-sm text-muted-foreground">Process winnings automatically</div>
                  </div>
                  <Switch
                    checked={autopilotSettings.payoutProcessing}
                    onCheckedChange={(checked) => toggleAutopilot("payoutProcessing", checked)}
                    disabled={!autopilotSettings.enabled}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">Maintenance Mode</div>
                    <div className="text-sm text-muted-foreground">Put app in maintenance mode</div>
                  </div>
                  <Switch
                    checked={autopilotSettings.maintenanceMode}
                    onCheckedChange={(checked) => toggleAutopilot("maintenanceMode", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="wallet" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Developer Wallet Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center p-6 bg-muted/30 rounded-lg">
                  <div className="text-3xl font-bold text-primary mb-2">
                    ₹{systemStats.developerWallet.toLocaleString()}
                  </div>
                  <div className="text-muted-foreground">Available Balance</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="w-full">
                        <Download className="w-4 h-4 mr-2" />
                        Withdraw Funds
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Withdraw from Developer Wallet</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Amount</Label>
                          <Input placeholder="Enter withdrawal amount" />
                        </div>
                        <div>
                          <Label>Method</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select withdrawal method" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="upi">UPI - 8976096360</SelectItem>
                              <SelectItem value="bank">Bank Transfer</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button className="w-full" onClick={() => withdrawFromDeveloperWallet(10000)}>
                          Confirm Withdrawal
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button variant="outline" className="w-full bg-transparent">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>System Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Restart Services
                  </Button>
                  <Button variant="outline">
                    <Database className="w-4 h-4 mr-2" />
                    Backup Database
                  </Button>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Export Logs
                  </Button>
                  <Button variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Update System
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
