"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  CreditCard,
  Smartphone,
  Building2,
  Shield,
  CheckCircle,
  Clock,
  AlertCircle,
  ArrowRight,
  Wallet,
  Banknote,
  Zap,
  Lock,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"

interface PaymentMethod {
  id: string
  name: string
  type: "upi" | "netbanking" | "card" | "wallet"
  icon: React.ReactNode
  processingTime: string
  fees: string
  available: boolean
}

interface Transaction {
  id: string
  amount: number
  method: string
  status: "pending" | "processing" | "completed" | "failed"
  timestamp: Date
  gatewayRef: string
}

export default function PaymentsPage() {
  const [selectedMethod, setSelectedMethod] = useState<string>("")
  const [amount, setAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentStep, setCurrentStep] = useState<"select" | "details" | "processing" | "success" | "failed">("select")
  const [upiId, setUpiId] = useState("")
  const [selectedBank, setSelectedBank] = useState("")
  const [cardDetails, setCardDetails] = useState({
    number: "",
    expiry: "",
    cvv: "",
    name: "",
  })

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: "TXN001",
      amount: 500,
      method: "UPI - PhonePe",
      status: "completed",
      timestamp: new Date(Date.now() - 3600000),
      gatewayRef: "PG_REF_001",
    },
    {
      id: "TXN002",
      amount: 1000,
      method: "Net Banking - SBI",
      status: "completed",
      timestamp: new Date(Date.now() - 7200000),
      gatewayRef: "PG_REF_002",
    },
  ])

  const paymentMethods: PaymentMethod[] = [
    {
      id: "upi",
      name: "UPI",
      type: "upi",
      icon: <Smartphone className="w-5 h-5" />,
      processingTime: "Instant",
      fees: "Free",
      available: true,
    },
    {
      id: "netbanking",
      name: "Net Banking",
      type: "netbanking",
      icon: <Building2 className="w-5 h-5" />,
      processingTime: "2-5 minutes",
      fees: "Free",
      available: true,
    },
    {
      id: "card",
      name: "Debit/Credit Card",
      type: "card",
      icon: <CreditCard className="w-5 h-5" />,
      processingTime: "Instant",
      fees: "2% + GST",
      available: true,
    },
    {
      id: "wallet",
      name: "Digital Wallet",
      type: "wallet",
      icon: <Wallet className="w-5 h-5" />,
      processingTime: "Instant",
      fees: "Free",
      available: true,
    },
  ]

  const banks = [
    "State Bank of India",
    "HDFC Bank",
    "ICICI Bank",
    "Axis Bank",
    "Punjab National Bank",
    "Bank of Baroda",
    "Canara Bank",
    "Union Bank of India",
  ]

  const upiApps = [
    { id: "phonepe", name: "PhonePe", icon: "📱" },
    { id: "googlepay", name: "Google Pay", icon: "🔵" },
    { id: "paytm", name: "Paytm", icon: "💙" },
    { id: "bhim", name: "BHIM UPI", icon: "🇮🇳" },
  ]

  const processPayment = async () => {
    setIsProcessing(true)
    setCurrentStep("processing")

    // Simulate payment processing
    setTimeout(() => {
      const success = Math.random() > 0.1 // 90% success rate

      if (success) {
        const newTransaction: Transaction = {
          id: `TXN${Date.now()}`,
          amount: Number.parseFloat(amount),
          method: getMethodName(),
          status: "completed",
          timestamp: new Date(),
          gatewayRef: `PG_REF_${Date.now()}`,
        }

        setTransactions((prev) => [newTransaction, ...prev])
        setCurrentStep("success")
        console.log(`[v0] Payment successful: ₹${amount} via ${getMethodName()}`)
      } else {
        setCurrentStep("failed")
        console.log(`[v0] Payment failed: ₹${amount} via ${getMethodName()}`)
      }

      setIsProcessing(false)
    }, 3000)
  }

  const getMethodName = () => {
    const method = paymentMethods.find((m) => m.id === selectedMethod)
    if (selectedMethod === "upi" && upiId) {
      return `UPI - ${upiId}`
    } else if (selectedMethod === "netbanking" && selectedBank) {
      return `Net Banking - ${selectedBank}`
    } else if (selectedMethod === "card") {
      return `Card - ****${cardDetails.number.slice(-4)}`
    }
    return method?.name || "Unknown"
  }

  const resetPayment = () => {
    setCurrentStep("select")
    setAmount("")
    setSelectedMethod("")
    setUpiId("")
    setSelectedBank("")
    setCardDetails({ number: "", expiry: "", cvv: "", name: "" })
    setIsProcessing(false)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case "processing":
        return <Clock className="w-4 h-4 text-yellow-500 animate-spin" />
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-500" />
      case "failed":
        return <AlertCircle className="w-4 h-4 text-red-500" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-gradient">SKILLZY</span>
            </Link>
            <Badge variant="secondary" className="pulse-neon">
              <CreditCard className="w-3 h-3 mr-1" />
              Payments
            </Badge>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="/wallet">
              <Button variant="ghost" size="sm">
                <Wallet className="w-4 h-4 mr-2" />
                Wallet
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {currentStep === "select" && (
          <>
            {/* Amount Selection */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Banknote className="w-5 h-5 mr-2" />
                  Add Money to Wallet
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="amount">Amount (₹10 - ₹50,000)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    min="10"
                    max="50000"
                    className="text-lg"
                  />
                </div>

                {/* Quick Amount Buttons */}
                <div className="grid grid-cols-4 gap-3">
                  {[100, 500, 1000, 2000].map((quickAmount) => (
                    <Button
                      key={quickAmount}
                      variant="outline"
                      onClick={() => setAmount(quickAmount.toString())}
                      className="h-12"
                    >
                      ₹{quickAmount}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <Card>
              <CardHeader>
                <CardTitle>Select Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {paymentMethods.map((method) => (
                      <div key={method.id} className="relative">
                        <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                        <Label
                          htmlFor={method.id}
                          className={`flex items-center space-x-4 p-4 border-2 rounded-lg cursor-pointer transition-all hover:border-primary/50 ${
                            selectedMethod === method.id
                              ? "border-primary bg-primary/5"
                              : "border-border hover:bg-muted/30"
                          } ${!method.available ? "opacity-50 cursor-not-allowed" : ""}`}
                        >
                          <div className="flex-shrink-0">{method.icon}</div>
                          <div className="flex-1">
                            <div className="font-semibold">{method.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {method.processingTime} • {method.fees}
                            </div>
                          </div>
                          {selectedMethod === method.id && <CheckCircle className="w-5 h-5 text-primary" />}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>

                <Button
                  onClick={() => setCurrentStep("details")}
                  disabled={!amount || !selectedMethod || Number.parseFloat(amount) < 10}
                  className="w-full mt-6 glow-effect"
                >
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Continue
                </Button>
              </CardContent>
            </Card>
          </>
        )}

        {currentStep === "details" && (
          <Card>
            <CardHeader>
              <CardTitle>Payment Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Amount Summary */}
              <div className="p-4 bg-muted/30 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-lg">Amount to Add</span>
                  <span className="text-2xl font-bold text-primary">₹{amount}</span>
                </div>
              </div>

              {/* UPI Details */}
              {selectedMethod === "upi" && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="upi-id">UPI ID</Label>
                    <Input
                      id="upi-id"
                      placeholder="yourname@upi"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                    />
                  </div>

                  <div>
                    <Label>Or choose UPI app</Label>
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      {upiApps.map((app) => (
                        <Button
                          key={app.id}
                          variant="outline"
                          onClick={() => setUpiId(`user@${app.id}`)}
                          className="justify-start"
                        >
                          <span className="mr-2">{app.icon}</span>
                          {app.name}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Net Banking Details */}
              {selectedMethod === "netbanking" && (
                <div>
                  <Label htmlFor="bank">Select Your Bank</Label>
                  <Select value={selectedBank} onValueChange={setSelectedBank}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your bank" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks.map((bank) => (
                        <SelectItem key={bank} value={bank}>
                          {bank}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Card Details */}
              {selectedMethod === "card" && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="card-number">Card Number</Label>
                    <Input
                      id="card-number"
                      placeholder="1234 5678 9012 3456"
                      value={cardDetails.number}
                      onChange={(e) =>
                        setCardDetails((prev) => ({ ...prev, number: e.target.value.replace(/\D/g, "") }))
                      }
                      maxLength={16}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input
                        id="expiry"
                        placeholder="MM/YY"
                        value={cardDetails.expiry}
                        onChange={(e) => setCardDetails((prev) => ({ ...prev, expiry: e.target.value }))}
                        maxLength={5}
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        placeholder="123"
                        value={cardDetails.cvv}
                        onChange={(e) =>
                          setCardDetails((prev) => ({ ...prev, cvv: e.target.value.replace(/\D/g, "") }))
                        }
                        maxLength={3}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="card-name">Cardholder Name</Label>
                    <Input
                      id="card-name"
                      placeholder="Name as on card"
                      value={cardDetails.name}
                      onChange={(e) => setCardDetails((prev) => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                </div>
              )}

              {/* Security Notice */}
              <div className="flex items-start space-x-3 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                <Shield className="w-5 h-5 text-green-500 mt-0.5" />
                <div className="text-sm">
                  <div className="font-semibold text-green-500 mb-1">Secure Payment</div>
                  <div className="text-muted-foreground">
                    Your payment information is encrypted and secure. We use industry-standard security measures.
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <Button variant="outline" onClick={() => setCurrentStep("select")} className="flex-1">
                  Back
                </Button>
                <Button onClick={processPayment} className="flex-1 glow-effect">
                  <Lock className="w-4 h-4 mr-2" />
                  Pay ₹{amount}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === "processing" && (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="w-8 h-8 text-primary animate-spin" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Processing Payment</h3>
              <p className="text-muted-foreground mb-4">Please wait while we process your payment of ₹{amount}</p>
              <div className="text-sm text-muted-foreground">Do not close this window or press the back button</div>
            </CardContent>
          </Card>
        )}

        {currentStep === "success" && (
          <Card className="border-green-500/20 bg-green-500/5">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
              <h3 className="text-2xl font-semibold text-green-500 mb-2">Payment Successful!</h3>
              <p className="text-muted-foreground mb-6">₹{amount} has been added to your wallet successfully</p>

              <div className="space-y-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Amount</div>
                      <div className="font-semibold">₹{amount}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Method</div>
                      <div className="font-semibold">{getMethodName()}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Transaction ID</div>
                      <div className="font-semibold">TXN{Date.now()}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Status</div>
                      <div className="font-semibold text-green-500">Completed</div>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Link href="/wallet" className="flex-1">
                    <Button className="w-full">
                      <Wallet className="w-4 h-4 mr-2" />
                      View Wallet
                    </Button>
                  </Link>
                  <Button variant="outline" onClick={resetPayment} className="flex-1 bg-transparent">
                    Add More Money
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === "failed" && (
          <Card className="border-red-500/20 bg-red-500/5">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-10 h-10 text-red-500" />
              </div>
              <h3 className="text-2xl font-semibold text-red-500 mb-2">Payment Failed</h3>
              <p className="text-muted-foreground mb-6">
                We couldn't process your payment of ₹{amount}. Please try again.
              </p>

              <div className="flex space-x-4">
                <Button onClick={resetPayment} className="flex-1">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Link href="/wallet" className="flex-1">
                  <Button variant="outline" className="w-full bg-transparent">
                    Go to Wallet
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Transaction History */}
        {currentStep === "select" && transactions.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.slice(0, 5).map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      {getStatusIcon(transaction.status)}
                      <div>
                        <div className="font-semibold">₹{transaction.amount.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">{transaction.method}</div>
                        <div className="text-xs text-muted-foreground">{transaction.timestamp.toLocaleString()}</div>
                      </div>
                    </div>

                    <div className="text-right">
                      <Badge
                        variant={
                          transaction.status === "completed"
                            ? "default"
                            : transaction.status === "failed"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {transaction.status}
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-1">{transaction.gatewayRef}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
